import { Database } from 'sqlite';
export declare function initializeDatabase(): Promise<void>;
export declare function getDatabase(): Database;
export declare function closeDatabase(): Promise<void>;
//# sourceMappingURL=setup.d.ts.map