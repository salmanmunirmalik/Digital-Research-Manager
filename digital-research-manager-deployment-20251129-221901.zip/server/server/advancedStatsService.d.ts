export default AdvancedStatisticalService;
declare class AdvancedStatisticalService {
    pythonServiceUrl: string;
    timeout: number;
    loadCSVData(filePath: any, options?: {}): Promise<{
        success: boolean;
        data: any;
        shape: any;
        columns: any;
        dtypes: any;
    }>;
    loadExcelData(filePath: any, options?: {}): Promise<{
        success: boolean;
        data: any;
        shape: any;
        columns: any;
        dtypes: any;
    }>;
    getDataInfo(data: any): Promise<{
        success: boolean;
        info: {
            shape: any;
            columns: any;
            dtypes: any;
            missingValues: any;
            memoryUsage: any;
            summary: any;
        };
    }>;
    selectColumns(data: any, columns: any): Promise<{
        success: boolean;
        data: any;
        shape: any;
    }>;
    removeDuplicates(data: any, subset?: null): Promise<{
        success: boolean;
        data: any;
        duplicatesRemoved: any;
        shape: any;
    }>;
    handleMissingValues(data: any, method?: string, fillValue?: null): Promise<{
        success: boolean;
        data: any;
        missingHandled: any;
        shape: any;
    }>;
    getDescriptiveStatistics(data: any, columns?: null): Promise<{
        success: boolean;
        statistics: {
            count: any;
            mean: any;
            std: any;
            min: any;
            max: any;
            percentiles: any;
            skewness: any;
            kurtosis: any;
        };
    }>;
    correlationAnalysis(data: any, method?: string, columns?: null): Promise<{
        success: boolean;
        correlation: {
            matrix: any;
            pValues: any;
            method: string;
        };
    }>;
    linearRegression(data: any, targetColumn: any, featureColumns?: null): Promise<{
        success: boolean;
        model: {
            coefficients: any;
            intercept: any;
            rSquared: any;
            adjustedRSquared: any;
            pValues: any;
            confidenceIntervals: any;
        };
        predictions: any;
        residuals: any;
    }>;
    clusteringAnalysis(data: any, nClusters?: number, algorithm?: string, columns?: null): Promise<{
        success: boolean;
        clusters: {
            labels: any;
            centers: any;
            inertia: any;
            silhouetteScore: any;
        };
        algorithm: string;
        nClusters: number;
    }>;
    hypothesisTesting(data: any, testType: any, columns: any, options?: {}): Promise<{
        success: boolean;
        testResults: {
            statistic: any;
            pValue: any;
            criticalValue: any;
            testType: any;
            conclusion: any;
        };
    }>;
    anovaAnalysis(data: any, groupColumn: any, valueColumn: any): Promise<{
        success: boolean;
        anovaResults: {
            fStatistic: any;
            pValue: any;
            dfBetween: any;
            dfWithin: any;
            sumSquaresBetween: any;
            sumSquaresWithin: any;
            meanSquareBetween: any;
            meanSquareWithin: any;
        };
    }>;
    createScatterPlot(data: any, xColumn: any, yColumn: any, options?: {}): Promise<{
        success: boolean;
        plot: {
            imageData: any;
            title: any;
            xLabel: any;
            yLabel: any;
        };
    }>;
    createHistogram(data: any, column: any, options?: {}): Promise<{
        success: boolean;
        plot: {
            imageData: any;
            title: any;
            bins: any;
            frequencies: any;
        };
    }>;
    createBoxPlot(data: any, columns: any, options?: {}): Promise<{
        success: boolean;
        plot: {
            imageData: any;
            title: any;
            statistics: any;
        };
    }>;
    createHeatmap(data: any, columns?: null, options?: {}): Promise<{
        success: boolean;
        plot: {
            imageData: any;
            title: any;
            correlationMatrix: any;
        };
    }>;
    createLineChart(data: any, xColumn: any, yColumn: any, options?: {}): Promise<{
        success: boolean;
        plot: {
            imageData: any;
            title: any;
            xLabel: any;
            yLabel: any;
        };
    }>;
    exportToCSV(data: any, filePath: any, options?: {}): Promise<{
        success: boolean;
        filePath: any;
        size: any;
    }>;
    exportToExcel(data: any, filePath: any, options?: {}): Promise<{
        success: boolean;
        filePath: any;
        size: any;
    }>;
    executeWorkflow(workflowNodes: any, workflowConnections: any, dataSets?: {}): Promise<{
        success: boolean;
        results: {};
        executionOrder: any[];
    }>;
    validateWorkflow(nodes: any, connections: any): void;
    getExecutionOrder(nodes: any, connections: any): any[];
    getNodeInputData(node: any, connections: any, results: any, dataSets: any): {
        data: any;
    };
    executeNode(node: any, inputData: any): Promise<{
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        info: {
            shape: any;
            columns: any;
            dtypes: any;
            missingValues: any;
            memoryUsage: any;
            summary: any;
        };
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        data: any;
        shape: any;
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        statistics: {
            count: any;
            mean: any;
            std: any;
            min: any;
            max: any;
            percentiles: any;
            skewness: any;
            kurtosis: any;
        };
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        correlation: {
            matrix: any;
            pValues: any;
            method: string;
        };
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        model: {
            coefficients: any;
            intercept: any;
            rSquared: any;
            adjustedRSquared: any;
            pValues: any;
            confidenceIntervals: any;
        };
        predictions: any;
        residuals: any;
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        clusters: {
            labels: any;
            centers: any;
            inertia: any;
            silhouetteScore: any;
        };
        algorithm: string;
        nClusters: number;
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        testResults: {
            statistic: any;
            pValue: any;
            criticalValue: any;
            testType: any;
            conclusion: any;
        };
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        anovaResults: {
            fStatistic: any;
            pValue: any;
            dfBetween: any;
            dfWithin: any;
            sumSquaresBetween: any;
            sumSquaresWithin: any;
            meanSquareBetween: any;
            meanSquareWithin: any;
        };
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        plot: {
            imageData: any;
            title: any;
            xLabel: any;
            yLabel: any;
        };
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        plot: {
            imageData: any;
            title: any;
            bins: any;
            frequencies: any;
        };
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        plot: {
            imageData: any;
            title: any;
            statistics: any;
        };
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        plot: {
            imageData: any;
            title: any;
            correlationMatrix: any;
        };
        error?: undefined;
    } | {
        nodeId: any;
        widgetId: any;
        outputs: {
            data: any;
            info: any;
            stats: any;
            correlation: any;
            model: any;
            predictions: any;
            clusters: any;
            test_results: any;
            anova_results: any;
            plot: any;
            file: any;
        };
        success: boolean;
        filePath: any;
        size: any;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        nodeId: any;
        widgetId: any;
    }>;
    formatOutputs(widgetId: any, result: any): {
        data: any;
        info: any;
        stats: any;
        correlation: any;
        model: any;
        predictions: any;
        clusters: any;
        test_results: any;
        anova_results: any;
        plot: any;
        file: any;
    };
    exportResultsToCSV(results: any): Promise<string>;
    exportResultsToExcel(results: any): Promise<string>;
    convertResultsToCSV(results: any): string;
    convertResultsToExcel(results: any): string;
    healthCheck(): Promise<{
        status: string;
        service: string;
        timestamp: string;
        pythonService: any;
        error?: undefined;
    } | {
        status: string;
        error: string;
        timestamp: string;
        service?: undefined;
        pythonService?: undefined;
    }>;
}
//# sourceMappingURL=advancedStatsService.d.ts.map