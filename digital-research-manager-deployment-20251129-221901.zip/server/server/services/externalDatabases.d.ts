/**
 * External Database Integration Service
 * Integrations for Materials Project, Lens.org, and other scientific databases
 * Based on user suggestions for current insights and materials data
 */
interface Material {
    materialId: string;
    formula: string;
    prettyFormula?: string;
    structure?: any;
    properties?: {
        bandGap?: number;
        density?: number;
        energyPerAtom?: number;
        formationEnergyPerAtom?: number;
        volume?: number;
    };
    symmetry?: {
        crystalSystem?: string;
        spaceGroup?: string;
    };
    stability?: number;
    isStable?: boolean;
    tasks?: string[];
    warnings?: string[];
}
export declare class MaterialsProjectService {
    private baseUrl;
    private apiKey;
    constructor(apiKey?: string);
    /**
     * Search for materials by formula
     */
    searchByFormula(formula: string): Promise<Material[]>;
    /**
     * Search materials by elements
     */
    searchByElements(elements: string[], isStable?: boolean): Promise<Material[]>;
    /**
     * Get material by Materials Project ID
     */
    getMaterialById(materialId: string): Promise<Material | null>;
    /**
     * Search materials with band gap constraints (for semiconductor research)
     */
    searchByBandGap(minGap: number, maxGap: number): Promise<Material[]>;
    /**
     * Get similar materials based on structure
     */
    getSimilarMaterials(materialId: string): Promise<Material[]>;
    private parseMaterialsResponse;
}
interface LensScholarlyWork {
    lensId: string;
    title: string;
    authors: any[];
    abstract?: string;
    year?: number;
    sourceTitle?: string;
    volume?: string;
    issue?: string;
    pages?: string;
    doi?: string;
    pmid?: string;
    citationCount?: number;
    references?: string[];
    keywords?: string[];
    fieldsOfStudy?: string[];
}
interface LensPatent {
    lensId: string;
    title: string;
    abstract?: string;
    inventors: any[];
    applicants: any[];
    publicationDate?: string;
    filingDate?: string;
    patentNumber?: string;
    jurisdictions?: string[];
    classifications?: string[];
    citationCount?: number;
    claims?: string[];
}
export declare class LensService {
    private baseUrl;
    private apiToken;
    constructor(apiToken?: string);
    /**
     * Search scholarly works (papers, articles)
     */
    searchScholarship(query: string, limit?: number): Promise<LensScholarlyWork[]>;
    /**
     * Search patents
     */
    searchPatents(query: string, limit?: number): Promise<LensPatent[]>;
    /**
     * Track citations for a specific DOI
     */
    trackCitations(doi: string): Promise<{
        citationCount: number;
        citingWorks: LensScholarlyWork[];
    }>;
    /**
     * Identify research trends in a domain
     */
    identifyTrends(domain: string, years?: number): Promise<any>;
    /**
     * Get scholarly work by Lens ID
     */
    getScholarlyWorkById(lensId: string): Promise<LensScholarlyWork | null>;
    private parseScholarlyResponse;
    private parsePatentResponse;
}
export declare class ScientificDatabaseService {
    private materialsProject;
    private lens;
    constructor();
    getMaterialsProject(): MaterialsProjectService;
    getLens(): LensService;
    /**
     * Comprehensive search across all databases
     */
    searchAll(query: string): Promise<{
        materials: Material[];
        papers: LensScholarlyWork[];
        patents: LensPatent[];
    }>;
    /**
     * Get research insights for a specific domain
     */
    getResearchInsights(domain: string): Promise<any>;
    /**
     * Materials discovery workflow
     */
    discoverMaterials(requirements: {
        elements?: string[];
        bandGapRange?: [number, number];
        properties?: string[];
    }): Promise<Material[]>;
    private generateInsightsSummary;
}
export declare const scientificDatabaseService: ScientificDatabaseService;
export {};
//# sourceMappingURL=externalDatabases.d.ts.map