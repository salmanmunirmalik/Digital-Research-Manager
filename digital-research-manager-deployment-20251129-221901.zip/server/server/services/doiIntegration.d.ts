/**
 * DOI Integration Service
 * Auto-fetch papers from CrossRef, PubMed, arXiv, and other academic databases
 * Implements Salman's suggestion: Fetch papers by DOI with option to save full paper or AI summary
 */
export interface Paper {
    doi?: string;
    pmid?: string;
    arxivId?: string;
    title: string;
    authors: Author[];
    abstract?: string;
    journal?: string;
    volume?: string;
    issue?: string;
    pages?: string;
    year: number;
    publicationDate?: string;
    url?: string;
    pdfUrl?: string;
    citationCount?: number;
    keywords?: string[];
    references?: string[];
    meshTerms?: string[];
    subjects?: string[];
    aiSummary?: string;
    keyFindings?: string[];
    methodology?: string;
    relevanceScore?: number;
}
interface Author {
    firstName: string;
    lastName: string;
    affiliation?: string;
    orcid?: string;
}
export declare class CrossRefService {
    private baseUrl;
    private email;
    fetchByDOI(doi: string): Promise<Paper | null>;
    searchPapers(query: string, limit?: number): Promise<Paper[]>;
    fetchByAuthorORCID(orcid: string): Promise<Paper[]>;
    private parseCrossRefResponse;
    private parseCrossRefItem;
    private parseAuthors;
    private extractYear;
    private formatDate;
    private cleanDOI;
}
export declare class PubMedService {
    private baseUrl;
    fetchByPMID(pmid: string): Promise<Paper | null>;
    search(query: string, limit?: number): Promise<string[]>;
    fetchByAuthorName(authorName: string, limit?: number): Promise<string[]>;
    private parsePubMedXML;
}
export declare class ArXivService {
    private baseUrl;
    fetchByArXivId(arxivId: string): Promise<Paper | null>;
    search(query: string, limit?: number): Promise<Paper[]>;
    private parseArXivAtom;
    private parseArXivAtomFeed;
}
export declare class PaperFetchingService {
    private crossRef;
    private pubMed;
    private arXiv;
    constructor();
    /**
     * Smart paper fetching - detects identifier type and fetches from appropriate source
     */
    fetchPaper(identifier: string): Promise<Paper | null>;
    /**
     * Fetch all papers by author's ORCID
     */
    fetchPapersByORCID(orcid: string): Promise<Paper[]>;
    /**
     * Search across all databases
     */
    searchAcrossAll(query: string, limit?: number): Promise<Paper[]>;
    /**
     * Generate AI summary for a paper (placeholder for AI integration)
     */
    generateAISummary(paper: Paper): Promise<string>;
    /**
     * Extract key findings using AI (placeholder)
     */
    extractKeyFindings(paper: Paper): Promise<string[]>;
    /**
     * Extract methodology using AI (placeholder)
     */
    extractMethodology(paper: Paper): Promise<string>;
    /**
     * Calculate relevance to user's work (placeholder)
     */
    calculateRelevance(paper: Paper, userProfile: any): Promise<number>;
    private isDOI;
    private isPMID;
    private isArXivId;
    private deduplicatePapers;
}
export declare const paperFetchingService: PaperFetchingService;
export {};
//# sourceMappingURL=doiIntegration.d.ts.map