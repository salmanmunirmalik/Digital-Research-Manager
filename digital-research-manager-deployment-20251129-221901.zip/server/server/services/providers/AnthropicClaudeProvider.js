/**
 * Anthropic Claude Provider Implementation
 * Task 3: Implement AnthropicProvider class
 */
import axios from 'axios';
export class AnthropicClaudeProvider {
    provider = 'anthropic_claude';
    providerName = 'Anthropic Claude';
    apiKey;
    baseUrl = 'https://api.anthropic.com/v1';
    constructor(apiKey) {
        this.apiKey = apiKey;
    }
    supportsChat() {
        return true;
    }
    supportsEmbeddings() {
        return false; // Claude doesn't have native embeddings
    }
    supportsImageGeneration() {
        return false;
    }
    getDefaultChatModel() {
        return 'claude-3-opus-20240229';
    }
    getDefaultEmbeddingModel() {
        throw new Error('Claude does not support embeddings');
    }
    async chat(messages, config) {
        const model = config?.model || this.getDefaultChatModel();
        const maxTokens = config?.maxTokens ?? 2000;
        // Separate system message from other messages
        const systemMessage = messages.find(msg => msg.role === 'system');
        const conversationMessages = messages
            .filter(msg => msg.role !== 'system')
            .map(msg => ({
            role: msg.role === 'assistant' ? 'assistant' : 'user',
            content: msg.content
        }));
        try {
            const response = await axios.post(`${this.baseUrl}/messages`, {
                model,
                max_tokens: maxTokens,
                system: systemMessage?.content,
                messages: conversationMessages
            }, {
                headers: {
                    'x-api-key': this.apiKey,
                    'anthropic-version': '2023-06-01',
                    'Content-Type': 'application/json'
                }
            });
            const data = response.data;
            return {
                content: data.content[0].text,
                model: data.model,
                usage: {
                    promptTokens: data.usage?.input_tokens,
                    completionTokens: data.usage?.output_tokens,
                    totalTokens: (data.usage?.input_tokens || 0) + (data.usage?.output_tokens || 0)
                },
                metadata: {
                    stopReason: data.stop_reason
                }
            };
        }
        catch (error) {
            throw new Error(`Anthropic Claude API error: ${error.response?.data?.error?.message || error.message}`);
        }
    }
    async embed(text, config) {
        throw new Error('Claude does not support embeddings. Use OpenAI or Google Gemini for embeddings.');
    }
    async validateApiKey(apiKey) {
        try {
            // Test with a simple request
            await axios.post(`${this.baseUrl}/messages`, {
                model: 'claude-3-haiku-20240307',
                max_tokens: 10,
                messages: [{ role: 'user', content: 'test' }]
            }, {
                headers: {
                    'x-api-key': apiKey,
                    'anthropic-version': '2023-06-01',
                    'Content-Type': 'application/json'
                }
            });
            return true;
        }
        catch (error) {
            // 401 means invalid key, but other errors might mean valid key
            return error.response?.status !== 401;
        }
    }
}
//# sourceMappingURL=AnthropicClaudeProvider.js.map