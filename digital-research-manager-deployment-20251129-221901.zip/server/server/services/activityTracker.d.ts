export declare class ActivityTracker {
    static trackLabNotebookEntry(userId: string, entryData: any): Promise<void>;
    static trackProtocolCreation(userId: string, protocolData: any): Promise<void>;
    static trackExperimentCompletion(userId: string, experimentData: any): Promise<void>;
    static trackCollaboration(userId: string, collaborationData: any): Promise<void>;
    static trackPublication(userId: string, publicationData: any): Promise<void>;
    static extractSkillsFromContent(content: string): string[];
    static extractSkillsFromProtocol(protocolData: any): string[];
    static extractSkillsFromExperiment(experimentData: any): string[];
    static generateActivitySummary(userId: string, periodMonths?: number): Promise<{
        period: string;
        totalActivities: number;
        activityBreakdown: any[];
        topSkills: any[];
        averageScore: number;
    } | null>;
}
export declare const trackActivityMiddleware: (activityType: string) => (req: any, res: any, next: any) => void;
export default ActivityTracker;
//# sourceMappingURL=activityTracker.d.ts.map