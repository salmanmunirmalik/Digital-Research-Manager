export interface UniversityDomain {
    domain: string;
    institution: string;
    country: string;
    verified: boolean;
}
export declare class UniversityEmailValidator {
    private static universityDomains;
    /**
     * Validates if an email address belongs to a recognized university domain
     */
    static validateUniversityEmail(email: string): {
        isValid: boolean;
        institution?: string;
        country?: string;
        domain?: string;
        verified: boolean;
    };
    /**
     * Gets all supported university domains
     */
    static getSupportedDomains(): UniversityDomain[];
    /**
     * Checks if a domain is a verified university domain
     */
    static isVerifiedDomain(domain: string): boolean;
    /**
     * Suggests similar university domains for typos
     */
    static suggestDomains(inputDomain: string): UniversityDomain[];
}
export default UniversityEmailValidator;
//# sourceMappingURL=universityEmailValidator.d.ts.map