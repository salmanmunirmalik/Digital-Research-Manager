/**
 * AI Provider Abstraction Interface
 * Task 1: Create standardized interface for all AI providers
 *
 * This interface allows the system to work with any AI provider
 * through a unified API, making it easy to add new providers
 * and switch between them dynamically.
 */
/**
 * Provider Registry
 * Stores capabilities of all providers
 */
export class ProviderCapabilityRegistry {
    static capabilities = new Map([
        ['openai', {
                provider: 'openai',
                strengths: ['writing', 'code', 'analysis'],
                bestFor: ['content_writing', 'abstract_writing', 'code_generation'],
                contextLength: 128000,
                speed: 'medium',
                cost: 'high',
                quality: 'high'
            }],
        ['google_gemini', {
                provider: 'google_gemini',
                strengths: ['reasoning', 'multimodal', 'research'],
                bestFor: ['paper_finding', 'data_analysis', 'idea_generation'],
                contextLength: 1000000,
                speed: 'fast',
                cost: 'medium',
                quality: 'high'
            }],
        ['anthropic_claude', {
                provider: 'anthropic_claude',
                strengths: ['reasoning', 'analysis', 'long_context'],
                bestFor: ['proposal_writing', 'data_analysis', 'paper_generation'],
                contextLength: 200000,
                speed: 'medium',
                cost: 'high',
                quality: 'high'
            }],
        ['perplexity', {
                provider: 'perplexity',
                strengths: ['search', 'real_time', 'research'],
                bestFor: ['paper_finding', 'research', 'summarization'],
                contextLength: 100000,
                speed: 'fast',
                cost: 'medium',
                quality: 'high'
            }]
    ]);
    /**
     * Get capabilities for a provider
     */
    static getCapabilities(provider) {
        return this.capabilities.get(provider) || null;
    }
    /**
     * Get best provider for a task
     */
    static getBestProviderForTask(taskType) {
        for (const [provider, capabilities] of this.capabilities.entries()) {
            if (capabilities.bestFor.includes(taskType)) {
                return provider;
            }
        }
        return 'openai'; // Default fallback
    }
    /**
     * Register new provider capabilities
     */
    static register(capabilities) {
        this.capabilities.set(capabilities.provider, capabilities);
    }
    /**
     * Get all registered providers
     */
    static getAllProviders() {
        return Array.from(this.capabilities.keys());
    }
}
//# sourceMappingURL=AIProvider.js.map