/**
 * Base Agent Interface
 * Task 7: Create standardized interface for all AI agents
 *
 * All specialized agents (PaperFindingAgent, AbstractWritingAgent, etc.)
 * implement this interface to ensure consistency and interoperability.
 */
/**
 * Base Agent Implementation
 * Provides common functionality for all agents
 */
export class BaseAgent {
    aiProvider = null;
    /**
     * Initialize agent with AI provider
     */
    async initializeProvider(provider, apiKey) {
        const { AIProviderFactory } = await import('./AIProviderFactory.js');
        this.aiProvider = AIProviderFactory.createProvider(provider, apiKey);
    }
    /**
     * Get AI provider for this agent
     */
    getProvider() {
        if (!this.aiProvider) {
            throw new Error('Agent provider not initialized. Call initializeProvider() first.');
        }
        return this.aiProvider;
    }
    /**
     * Build system prompt for the agent
     */
    buildSystemPrompt(taskAnalysis, userContext) {
        const taskDescriptions = {
            'paper_finding': 'You are a research assistant specialized in finding and analyzing academic papers. Provide comprehensive search results with summaries, relevance scores, and key findings.',
            'abstract_writing': 'You are a scientific writing assistant. Generate well-structured abstracts following academic standards (Background, Methods, Results, Conclusions).',
            'content_writing': 'You are a professional content writer. Create high-quality, well-structured content that is clear, concise, and engaging.',
            'idea_generation': 'You are a research ideation expert. Generate creative, feasible, and innovative research ideas with clear hypotheses and potential impact.',
            'proposal_writing': 'You are a grant writing specialist. Create comprehensive research proposals with clear objectives, methodology, expected outcomes, and budget justification.',
            'data_analysis': 'You are a data analysis expert. Analyze experimental data, identify patterns, provide statistical insights, and suggest interpretations.',
            'image_creation': 'You are an image generation assistant. Create visual content, scientific figures, and diagrams based on descriptions.',
            'paper_generation': 'You are a scientific paper writing assistant. Generate complete research papers with proper structure, citations, and academic rigor.',
            'presentation_generation': 'You are a presentation creator. Generate professional presentation content with clear slides and engaging narratives.',
            'code_generation': 'You are a code generation assistant. Write clean, well-documented, and efficient code.',
            'translation': 'You are a translation expert. Provide accurate, context-aware translations while preserving technical terminology.',
            'summarization': 'You are a summarization expert. Create concise, informative summaries that capture key points and main findings.'
        };
        const basePrompt = taskDescriptions[this.agentType] || 'You are a helpful research assistant.';
        const userName = userContext?.user?.first_name ? ` The user's name is ${userContext.user.first_name}.` : '';
        const institution = userContext?.user?.current_institution ? ` They work at ${userContext.user.current_institution}.` : '';
        return `${basePrompt}${userName}${institution} Provide accurate, helpful responses based on the user's research context.`;
    }
    /**
     * Build user prompt with context
     */
    buildUserPrompt(input, userContext, taskAnalysis) {
        let prompt = input;
        if (userContext && taskAnalysis?.requiresContext) {
            const contextParts = [];
            if (userContext.user?.research_interests && userContext.user.research_interests.length > 0) {
                contextParts.push(`Research Interests: ${userContext.user.research_interests.join(', ')}`);
            }
            if (userContext.relevantContent && userContext.relevantContent.length > 0) {
                contextParts.push('\n--- Relevant Research Context ---');
                userContext.relevantContent.slice(0, 3).forEach((item, idx) => {
                    contextParts.push(`${idx + 1}. ${item.title}: ${item.content?.substring(0, 200)}...`);
                });
            }
            if (userContext.papers && userContext.papers.length > 0) {
                contextParts.push('\n--- Recent Papers ---');
                userContext.papers.slice(0, 3).forEach((paper, idx) => {
                    contextParts.push(`${idx + 1}. ${paper.title} (${paper.journal || 'Unknown'}, ${paper.year || 'Unknown'})`);
                });
            }
            if (contextParts.length > 0) {
                prompt = `${input}\n\n--- Context ---\n${contextParts.join('\n')}`;
            }
        }
        return prompt;
    }
    /**
     * Handle errors consistently
     */
    handleError(error, operation) {
        console.error(`[${this.agentName}] Error in ${operation}:`, error);
        return {
            success: false,
            content: null,
            error: error.message || `Failed to execute ${operation}`,
            metadata: {
                errorType: error.constructor?.name || 'UnknownError'
            }
        };
    }
}
//# sourceMappingURL=Agent.js.map