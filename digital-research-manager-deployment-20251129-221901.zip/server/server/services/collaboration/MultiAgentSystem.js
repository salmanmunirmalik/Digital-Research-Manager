/**
 * Multi-Agent System
 * Task 23: Implement MultiAgentSystem for collaboration
 *
 * Enables multiple agents to collaborate on complex tasks by:
 * - Sharing information and results
 * - Coordinating actions
 * - Resolving conflicts
 * - Synthesizing collective knowledge
 */
import { AgentFactory } from '../AgentFactory.js';
import { EventEmitter } from 'events';
export class MultiAgentSystem extends EventEmitter {
    agents = new Map();
    agentCapabilities = new Map();
    messageQueue = [];
    activeCollaborations = new Map();
    messageHistory = [];
    /**
     * Register an agent in the system
     */
    registerAgent(agentType, agent, capabilities) {
        this.agents.set(agentType, agent);
        this.agentCapabilities.set(agentType, capabilities);
        this.emit('agent:registered', { agentType, capabilities });
    }
    /**
     * Get agent by type
     */
    getAgent(agentType) {
        return this.agents.get(agentType);
    }
    /**
     * Get all registered agents
     */
    getAllAgents() {
        return Array.from(this.agents.keys());
    }
    /**
     * Get agent capabilities
     */
    getAgentCapabilities(agentType) {
        return this.agentCapabilities.get(agentType);
    }
    /**
     * Find agents with specific capabilities
     */
    findAgentsByCapability(capability) {
        const matchingAgents = [];
        this.agentCapabilities.forEach((cap, agentType) => {
            if (cap.capabilities.includes(capability) || cap.expertise.includes(capability)) {
                matchingAgents.push(agentType);
            }
        });
        return matchingAgents;
    }
    /**
     * Send message between agents
     */
    sendMessage(message) {
        this.messageQueue.push(message);
        this.messageHistory.push(message);
        // Emit event for message handling
        this.emit('message:sent', message);
        // Process message if target is specific
        if (message.to !== 'broadcast') {
            this.processMessage(message);
        }
        else {
            // Broadcast to all agents
            this.agents.forEach((agent, agentType) => {
                if (agentType !== message.from) {
                    this.processMessage({ ...message, to: agentType });
                }
            });
        }
    }
    /**
     * Process a message
     */
    processMessage(message) {
        const targetAgent = this.agents.get(message.to);
        if (!targetAgent) {
            console.warn(`Agent ${message.to} not found for message ${message.messageId}`);
            return;
        }
        // Emit event for message received
        this.emit('message:received', { message, agent: message.to });
        // Handle different message types
        switch (message.type) {
            case 'request':
                this.handleRequest(message);
                break;
            case 'query':
                this.handleQuery(message);
                break;
            case 'notification':
                this.handleNotification(message);
                break;
            default:
                // Response and result messages are handled by the sender
                break;
        }
    }
    /**
     * Handle request message
     */
    async handleRequest(message) {
        // In a full implementation, this would trigger the target agent to process the request
        // For now, we emit an event that can be handled by workflow orchestrators
        this.emit('agent:request', message);
    }
    /**
     * Handle query message
     */
    handleQuery(message) {
        // Agents can query each other for information
        this.emit('agent:query', message);
    }
    /**
     * Handle notification message
     */
    handleNotification(message) {
        // Agents can notify each other of events or state changes
        this.emit('agent:notification', message);
    }
    /**
     * Initiate collaboration between multiple agents
     */
    async initiateCollaboration(taskId, description, requiredCapabilities, agentTypes, context) {
        // Validate agents are available
        const availableAgents = agentTypes.filter(agentType => {
            const cap = this.agentCapabilities.get(agentType);
            return cap && cap.availability === 'available';
        });
        if (availableAgents.length === 0) {
            throw new Error('No available agents for collaboration');
        }
        // Create collaboration task
        const collaboration = {
            taskId,
            description,
            requiredCapabilities,
            assignedAgents: availableAgents,
            status: 'in_progress',
            results: new Map(),
            dependencies: []
        };
        this.activeCollaborations.set(taskId, collaboration);
        // Mark agents as busy
        availableAgents.forEach(agentType => {
            const cap = this.agentCapabilities.get(agentType);
            if (cap) {
                cap.availability = 'busy';
                cap.currentTask = taskId;
            }
        });
        this.emit('collaboration:started', collaboration);
        return collaboration;
    }
    /**
     * Submit result from an agent in a collaboration
     */
    submitCollaborationResult(taskId, agentType, result) {
        const collaboration = this.activeCollaborations.get(taskId);
        if (!collaboration) {
            throw new Error(`Collaboration ${taskId} not found`);
        }
        collaboration.results.set(agentType, result);
        // Check if all agents have completed
        const allCompleted = collaboration.assignedAgents.every(agentType => collaboration.results.has(agentType));
        if (allCompleted) {
            collaboration.status = 'completed';
            this.completeCollaboration(taskId);
        }
        this.emit('collaboration:result', { taskId, agentType, result });
    }
    /**
     * Complete collaboration and synthesize results
     */
    completeCollaboration(taskId) {
        const collaboration = this.activeCollaborations.get(taskId);
        if (!collaboration)
            return;
        // Synthesize results from all agents
        const synthesizedResult = this.synthesizeCollaborationResults(collaboration);
        // Mark agents as available
        collaboration.assignedAgents.forEach(agentType => {
            const cap = this.agentCapabilities.get(agentType);
            if (cap) {
                cap.availability = 'available';
                cap.currentTask = undefined;
            }
        });
        // Create collaboration result
        const result = {
            success: collaboration.results.size > 0 &&
                Array.from(collaboration.results.values()).every(r => r.success),
            taskId,
            results: collaboration.results,
            synthesizedResult,
            collaborationLog: this.messageHistory.filter(m => m.content?.taskId === taskId),
            metadata: {
                agentsInvolved: collaboration.assignedAgents,
                totalMessages: this.messageHistory.filter(m => m.content?.taskId === taskId).length,
                duration: 0 // Would track actual duration
            }
        };
        this.activeCollaborations.delete(taskId);
        this.emit('collaboration:completed', result);
    }
    /**
     * Synthesize results from multiple agents
     */
    synthesizeCollaborationResults(collaboration) {
        const results = {
            collaboration: collaboration.description,
            agents: collaboration.assignedAgents,
            results: {}
        };
        collaboration.results.forEach((result, agentType) => {
            results.results[agentType] = result.content;
        });
        // Merge key results
        const allResults = Array.from(collaboration.results.values());
        if (allResults.length > 0) {
            // Try to merge common structures
            const merged = {};
            allResults.forEach(result => {
                if (result.success && result.content) {
                    Object.assign(merged, result.content);
                }
            });
            results.merged = merged;
        }
        return results;
    }
    /**
     * Get active collaborations
     */
    getActiveCollaborations() {
        return Array.from(this.activeCollaborations.values());
    }
    /**
     * Get collaboration by ID
     */
    getCollaboration(taskId) {
        return this.activeCollaborations.get(taskId);
    }
    /**
     * Query agent for information
     */
    async queryAgent(fromAgent, toAgent, query, context) {
        const message = {
            from: fromAgent,
            to: toAgent,
            type: 'query',
            content: { query, context },
            timestamp: Date.now(),
            messageId: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
        };
        this.sendMessage(message);
        // Wait for response (in a real implementation, this would be async)
        return new Promise((resolve) => {
            const handler = (response) => {
                if (response.correlationId === message.messageId) {
                    this.off('message:response', handler);
                    resolve(response);
                }
            };
            this.on('message:response', handler);
        });
    }
    /**
     * Initialize system with default agents
     */
    initializeDefaultAgents() {
        const defaultAgents = [
            'paper_finding',
            'abstract_writing',
            'idea_generation',
            'proposal_writing',
            'literature_review',
            'experiment_design',
            'data_analysis',
            'data_reading',
            'paper_writing',
            'figure_generation',
            'reference_management',
            'draft_compilation',
            'presentation_slide',
            'quality_validation',
            'output_formatting'
        ];
        defaultAgents.forEach(agentType => {
            try {
                const agent = AgentFactory.createAgent(agentType);
                const capabilities = this.inferCapabilities(agentType);
                this.registerAgent(agentType, agent, capabilities);
            }
            catch (error) {
                console.warn(`Failed to register agent ${agentType}:`, error);
            }
        });
    }
    /**
     * Infer capabilities from agent type
     */
    inferCapabilities(agentType) {
        const capabilityMap = {
            'paper_finding': {
                agentType,
                capabilities: ['search', 'find', 'discover'],
                expertise: ['literature', 'research', 'papers'],
                availability: 'available'
            },
            'abstract_writing': {
                agentType,
                capabilities: ['write', 'summarize', 'abstract'],
                expertise: ['writing', 'summarization'],
                availability: 'available'
            },
            'data_analysis': {
                agentType,
                capabilities: ['analyze', 'statistics', 'insights'],
                expertise: ['data', 'statistics', 'analysis'],
                availability: 'available'
            },
            'experiment_design': {
                agentType,
                capabilities: ['design', 'plan', 'methodology'],
                expertise: ['experiments', 'methodology', 'design'],
                availability: 'available'
            },
            'paper_writing': {
                agentType,
                capabilities: ['write', 'compose', 'structure'],
                expertise: ['writing', 'papers', 'academic'],
                availability: 'available'
            }
        };
        return capabilityMap[agentType] || {
            agentType,
            capabilities: ['process', 'execute'],
            expertise: [agentType],
            availability: 'available'
        };
    }
}
// Singleton instance
export const multiAgentSystem = new MultiAgentSystem();
//# sourceMappingURL=MultiAgentSystem.js.map