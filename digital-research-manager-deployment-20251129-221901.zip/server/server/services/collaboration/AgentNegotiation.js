/**
 * Agent Negotiation Mechanisms
 * Task 25: Create agent negotiation mechanisms
 *
 * Enables agents to negotiate:
 * - Task assignment
 * - Resource allocation
 * - Conflict resolution
 * - Priority determination
 * - Collaboration terms
 */
import { EventEmitter } from 'events';
export class AgentNegotiation extends EventEmitter {
    negotiations = new Map();
    communicationProtocol;
    constructor(communicationProtocol) {
        super();
        this.communicationProtocol = communicationProtocol;
        this.setupMessageHandlers();
    }
    /**
     * Setup message handlers for negotiation
     */
    setupMessageHandlers() {
        this.communicationProtocol.on('message:received', (data) => {
            if (data.message.content?.negotiationId) {
                this.handleNegotiationMessage(data.message);
            }
        });
    }
    /**
     * Initiate a negotiation
     */
    initiateNegotiation(type, initiator, participants, initialProposal, options) {
        const negotiationId = `neg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const negotiation = {
            negotiationId,
            type,
            participants: [initiator, ...participants],
            initiator,
            status: 'initiated',
            proposals: [],
            history: [{
                    action: 'initiated',
                    agent: initiator,
                    timestamp: Date.now()
                }],
            deadline: options?.deadline,
            metadata: options?.metadata
        };
        this.negotiations.set(negotiationId, negotiation);
        // Create initial proposal
        const proposal = this.createProposal(negotiationId, initiator, participants[0], type, initialProposal);
        negotiation.proposals.push(proposal);
        negotiation.currentProposal = proposal;
        negotiation.status = 'proposed';
        // Send proposal to participants
        this.sendProposal(proposal);
        this.emit('negotiation:initiated', negotiation);
        return negotiation;
    }
    /**
     * Create a proposal
     */
    createProposal(negotiationId, from, to, type, terms, options) {
        const proposalId = `prop_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        return {
            proposalId,
            negotiationId,
            from,
            to,
            type,
            terms,
            priority: options?.priority || 50,
            timestamp: Date.now(),
            expiresAt: options?.expiresAt
        };
    }
    /**
     * Send proposal to agent
     */
    sendProposal(proposal) {
        const message = this.communicationProtocol.createRequest(proposal.from, proposal.to, {
            type: 'negotiation_proposal',
            proposal
        }, {
            timeout: proposal.expiresAt ? proposal.expiresAt - Date.now() : 30000,
            priority: proposal.priority > 70 ? 'high' : proposal.priority > 40 ? 'medium' : 'low'
        });
        this.communicationProtocol.sendMessage(message);
        this.emit('proposal:sent', proposal);
    }
    /**
     * Accept a proposal
     */
    acceptProposal(negotiationId, proposalId, agent) {
        const negotiation = this.negotiations.get(negotiationId);
        if (!negotiation) {
            throw new Error(`Negotiation ${negotiationId} not found`);
        }
        const proposal = negotiation.proposals.find(p => p.proposalId === proposalId);
        if (!proposal) {
            throw new Error(`Proposal ${proposalId} not found`);
        }
        if (proposal.to !== agent) {
            throw new Error(`Agent ${agent} is not the recipient of this proposal`);
        }
        negotiation.status = 'accepted';
        negotiation.acceptedProposal = proposal;
        negotiation.history.push({
            action: 'accepted',
            agent,
            timestamp: Date.now(),
            details: { proposalId }
        });
        // Notify all participants
        this.notifyParticipants(negotiation, 'accepted', { proposalId, agent });
        this.emit('negotiation:accepted', { negotiation, proposal, agent });
    }
    /**
     * Reject a proposal
     */
    rejectProposal(negotiationId, proposalId, agent, reason) {
        const negotiation = this.negotiations.get(negotiationId);
        if (!negotiation) {
            throw new Error(`Negotiation ${negotiationId} not found`);
        }
        const proposal = negotiation.proposals.find(p => p.proposalId === proposalId);
        if (!proposal) {
            throw new Error(`Proposal ${proposalId} not found`);
        }
        negotiation.status = 'rejected';
        negotiation.history.push({
            action: 'rejected',
            agent,
            timestamp: Date.now(),
            details: { proposalId, reason }
        });
        // Notify participants
        this.notifyParticipants(negotiation, 'rejected', { proposalId, agent, reason });
        this.emit('negotiation:rejected', { negotiation, proposal, agent, reason });
    }
    /**
     * Counter a proposal with a new proposal
     */
    counterProposal(negotiationId, originalProposalId, from, to, counterTerms, options) {
        const negotiation = this.negotiations.get(negotiationId);
        if (!negotiation) {
            throw new Error(`Negotiation ${negotiationId} not found`);
        }
        const counterProposal = this.createProposal(negotiationId, from, to, negotiation.type, counterTerms, options);
        negotiation.proposals.push(counterProposal);
        negotiation.currentProposal = counterProposal;
        negotiation.status = 'countered';
        negotiation.history.push({
            action: 'countered',
            agent: from,
            timestamp: Date.now(),
            details: { originalProposalId, counterProposalId: counterProposal.proposalId }
        });
        // Send counter proposal
        this.sendProposal(counterProposal);
        this.emit('negotiation:countered', { negotiation, counterProposal });
        return counterProposal;
    }
    /**
     * Handle negotiation message
     */
    handleNegotiationMessage(message) {
        const content = message.content;
        if (!content || !content.negotiationId)
            return;
        const negotiation = this.negotiations.get(content.negotiationId);
        if (!negotiation)
            return;
        if (content.type === 'negotiation_proposal') {
            this.emit('proposal:received', {
                negotiation,
                proposal: content.proposal,
                from: message.from
            });
        }
        else if (content.type === 'negotiation_response') {
            if (content.action === 'accept') {
                this.acceptProposal(content.negotiationId, content.proposalId, message.from);
            }
            else if (content.action === 'reject') {
                this.rejectProposal(content.negotiationId, content.proposalId, message.from, content.reason);
            }
            else if (content.action === 'counter') {
                // Counter proposal would be handled separately
            }
        }
    }
    /**
     * Notify all participants of negotiation status change
     */
    notifyParticipants(negotiation, action, details) {
        negotiation.participants.forEach(participant => {
            const message = this.communicationProtocol.createPublish('negotiation_system', `negotiation.${negotiation.negotiationId}`, {
                action,
                negotiationId: negotiation.negotiationId,
                details
            });
            this.communicationProtocol.sendMessage(message);
        });
    }
    /**
     * Get negotiation by ID
     */
    getNegotiation(negotiationId) {
        return this.negotiations.get(negotiationId);
    }
    /**
     * Get active negotiations
     */
    getActiveNegotiations() {
        return Array.from(this.negotiations.values()).filter(n => n.status === 'initiated' || n.status === 'proposed' || n.status === 'countered');
    }
    /**
     * Resolve conflict through negotiation
     */
    async resolveConflict(conflictId, conflictDescription, participants, proposedSolution, alternatives) {
        const negotiation = this.initiateNegotiation('conflict_resolution', participants[0], participants.slice(1), {
            conflictId,
            conflictDescription,
            proposedSolution,
            alternatives,
            rationale: 'Initial proposed solution'
        });
        // Wait for resolution (in real implementation, this would be async)
        return new Promise((resolve, reject) => {
            const checkResolution = () => {
                const updated = this.negotiations.get(negotiation.negotiationId);
                if (updated?.status === 'accepted') {
                    resolve(updated.acceptedProposal.terms);
                }
                else if (updated?.status === 'rejected') {
                    reject(new Error('Conflict resolution negotiation was rejected'));
                }
                else {
                    setTimeout(checkResolution, 1000);
                }
            };
            checkResolution();
        });
    }
    /**
     * Negotiate task assignment
     */
    negotiateTaskAssignment(taskId, taskDescription, requiredCapabilities, candidateAgents, initiator) {
        const proposal = {
            taskId,
            taskDescription,
            requiredCapabilities,
            estimatedDuration: 0, // Would be calculated
            priority: 50
        };
        return this.initiateNegotiation('task_assignment', initiator, candidateAgents, proposal);
    }
    /**
     * Negotiate resource allocation
     */
    negotiateResourceAllocation(resourceType, resourceId, quantity, duration, participants, initiator) {
        const proposal = {
            resourceType,
            resourceId,
            quantity,
            duration,
            priority: 50
        };
        return this.initiateNegotiation('resource_allocation', initiator, participants, proposal);
    }
}
// Singleton instance (requires communication protocol)
export function createAgentNegotiation(communicationProtocol) {
    return new AgentNegotiation(communicationProtocol);
}
//# sourceMappingURL=AgentNegotiation.js.map