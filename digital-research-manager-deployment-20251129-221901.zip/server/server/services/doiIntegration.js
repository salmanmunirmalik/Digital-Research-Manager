/**
 * DOI Integration Service
 * Auto-fetch papers from CrossRef, PubMed, arXiv, and other academic databases
 * Implements Salman's suggestion: Fetch papers by DOI with option to save full paper or AI summary
 */
import axios from 'axios';
// ==============================================
// CROSSREF API INTEGRATION
// ==============================================
export class CrossRefService {
    baseUrl = 'https://api.crossref.org/works';
    email = 'digital-research-manager@researchlab.com'; // Polite API access
    async fetchByDOI(doi) {
        try {
            const cleanDoi = this.cleanDOI(doi);
            const response = await axios.get(`${this.baseUrl}/${encodeURIComponent(cleanDoi)}`, {
                params: { mailto: this.email },
                timeout: 10000
            });
            return this.parseCrossRefResponse(response.data);
        }
        catch (error) {
            console.error('CrossRef API error:', error.message);
            return null;
        }
    }
    async searchPapers(query, limit = 10) {
        try {
            const response = await axios.get(`${this.baseUrl}`, {
                params: {
                    query: query,
                    rows: limit,
                    mailto: this.email
                },
                timeout: 10000
            });
            if (response.data?.message?.items) {
                return response.data.message.items.map((item) => this.parseCrossRefItem(item)).filter((paper) => paper !== null);
            }
            return [];
        }
        catch (error) {
            console.error('CrossRef search error:', error.message);
            return [];
        }
    }
    async fetchByAuthorORCID(orcid) {
        try {
            const response = await axios.get(`${this.baseUrl}`, {
                params: {
                    filter: `orcid:${orcid}`,
                    rows: 100,
                    mailto: this.email
                },
                timeout: 15000
            });
            if (response.data?.message?.items) {
                return response.data.message.items.map((item) => this.parseCrossRefItem(item)).filter((paper) => paper !== null);
            }
            return [];
        }
        catch (error) {
            console.error('CrossRef ORCID fetch error:', error.message);
            return [];
        }
    }
    parseCrossRefResponse(data) {
        const msg = data.message;
        return {
            doi: msg.DOI,
            title: Array.isArray(msg.title) ? msg.title[0] : msg.title,
            authors: this.parseAuthors(msg.author || []),
            abstract: msg.abstract,
            journal: msg['container-title']?.[0],
            volume: msg.volume,
            issue: msg.issue,
            pages: msg.page,
            year: this.extractYear(msg.published),
            publicationDate: this.formatDate(msg.published),
            url: msg.URL,
            citationCount: msg['is-referenced-by-count'],
            keywords: msg.subject || [],
        };
    }
    parseCrossRefItem(item) {
        try {
            return this.parseCrossRefResponse({ message: item });
        }
        catch (error) {
            return null;
        }
    }
    parseAuthors(authors) {
        return authors.map(author => ({
            firstName: author.given || '',
            lastName: author.family || '',
            affiliation: author.affiliation?.[0]?.name,
            orcid: author.ORCID?.replace('http://orcid.org/', '')
        }));
    }
    extractYear(published) {
        if (published?.['date-parts']?.[0]?.[0]) {
            return published['date-parts'][0][0];
        }
        return new Date().getFullYear();
    }
    formatDate(published) {
        if (published?.['date-parts']?.[0]) {
            const parts = published['date-parts'][0];
            return `${parts[0]}-${String(parts[1] || 1).padStart(2, '0')}-${String(parts[2] || 1).padStart(2, '0')}`;
        }
        return undefined;
    }
    cleanDOI(doi) {
        // Remove common prefixes
        return doi.replace(/^(https?:\/\/)?(dx\.)?doi\.org\//i, '');
    }
}
// ==============================================
// PUBMED API INTEGRATION
// ==============================================
export class PubMedService {
    baseUrl = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils';
    async fetchByPMID(pmid) {
        try {
            const response = await axios.get(`${this.baseUrl}/efetch.fcgi`, {
                params: {
                    db: 'pubmed',
                    id: pmid,
                    retmode: 'xml'
                },
                timeout: 10000
            });
            return this.parsePubMedXML(response.data);
        }
        catch (error) {
            console.error('PubMed API error:', error.message);
            return null;
        }
    }
    async search(query, limit = 10) {
        try {
            const response = await axios.get(`${this.baseUrl}/esearch.fcgi`, {
                params: {
                    db: 'pubmed',
                    term: query,
                    retmax: limit,
                    retmode: 'json'
                },
                timeout: 10000
            });
            return response.data?.esearchresult?.idlist || [];
        }
        catch (error) {
            console.error('PubMed search error:', error.message);
            return [];
        }
    }
    async fetchByAuthorName(authorName, limit = 50) {
        return this.search(`${authorName}[Author]`, limit);
    }
    parsePubMedXML(xml) {
        // Simplified XML parsing - in production, use xml2js or similar library
        // This is a placeholder implementation
        try {
            const titleMatch = xml.match(/<ArticleTitle>(.*?)<\/ArticleTitle>/);
            const pmidMatch = xml.match(/<PMID.*?>(.*?)<\/PMID>/);
            if (!titleMatch || !pmidMatch)
                return null;
            return {
                pmid: pmidMatch[1],
                title: titleMatch[1],
                authors: [], // Would parse from XML
                year: new Date().getFullYear(), // Would parse from XML
            };
        }
        catch (error) {
            return null;
        }
    }
}
// ==============================================
// ARXIV API INTEGRATION
// ==============================================
export class ArXivService {
    baseUrl = 'http://export.arxiv.org/api/query';
    async fetchByArXivId(arxivId) {
        try {
            const cleanId = arxivId.replace(/^arxiv:/i, '').replace(/^https?:\/\/arxiv\.org\/abs\//i, '');
            const response = await axios.get(this.baseUrl, {
                params: {
                    id_list: cleanId,
                    max_results: 1
                },
                timeout: 10000
            });
            return this.parseArXivAtom(response.data);
        }
        catch (error) {
            console.error('arXiv API error:', error.message);
            return null;
        }
    }
    async search(query, limit = 10) {
        try {
            const response = await axios.get(this.baseUrl, {
                params: {
                    search_query: `all:${query}`,
                    max_results: limit,
                    sortBy: 'relevance'
                },
                timeout: 10000
            });
            return this.parseArXivAtomFeed(response.data);
        }
        catch (error) {
            console.error('arXiv search error:', error.message);
            return [];
        }
    }
    parseArXivAtom(atom) {
        // Simplified ATOM parsing - in production, use xml2js
        try {
            const titleMatch = atom.match(/<title>(.*?)<\/title>/);
            const summaryMatch = atom.match(/<summary>(.*?)<\/summary>/s);
            const publishedMatch = atom.match(/<published>(.*?)<\/published>/);
            const idMatch = atom.match(/<id>(.*?)<\/id>/);
            if (!titleMatch || !idMatch)
                return null;
            const arxivId = idMatch[1].split('/').pop()?.replace('v', '');
            return {
                arxivId: arxivId,
                title: titleMatch[1].replace(/\s+/g, ' ').trim(),
                abstract: summaryMatch?.[1].replace(/\s+/g, ' ').trim(),
                year: publishedMatch ? new Date(publishedMatch[1]).getFullYear() : new Date().getFullYear(),
                authors: [], // Would parse from ATOM
                url: idMatch[1],
                pdfUrl: idMatch[1].replace('/abs/', '/pdf/') + '.pdf'
            };
        }
        catch (error) {
            return null;
        }
    }
    parseArXivAtomFeed(atom) {
        // Would parse multiple entries from ATOM feed
        // Placeholder implementation
        return [];
    }
}
// ==============================================
// UNIFIED PAPER FETCHING SERVICE
// ==============================================
export class PaperFetchingService {
    crossRef;
    pubMed;
    arXiv;
    constructor() {
        this.crossRef = new CrossRefService();
        this.pubMed = new PubMedService();
        this.arXiv = new ArXivService();
    }
    /**
     * Smart paper fetching - detects identifier type and fetches from appropriate source
     */
    async fetchPaper(identifier) {
        // Detect identifier type
        if (this.isDOI(identifier)) {
            return this.crossRef.fetchByDOI(identifier);
        }
        else if (this.isPMID(identifier)) {
            return this.pubMed.fetchByPMID(identifier);
        }
        else if (this.isArXivId(identifier)) {
            return this.arXiv.fetchByArXivId(identifier);
        }
        // If no specific format detected, try search across all
        const papers = await this.searchAcrossAll(identifier);
        return papers.length > 0 ? papers[0] : null;
    }
    /**
     * Fetch all papers by author's ORCID
     */
    async fetchPapersByORCID(orcid) {
        try {
            const papers = await this.crossRef.fetchByAuthorORCID(orcid);
            return papers;
        }
        catch (error) {
            console.error('Error fetching papers by ORCID:', error);
            return [];
        }
    }
    /**
     * Search across all databases
     */
    async searchAcrossAll(query, limit = 20) {
        const results = await Promise.allSettled([
            this.crossRef.searchPapers(query, limit),
            this.arXiv.search(query, limit / 2),
        ]);
        const papers = [];
        results.forEach(result => {
            if (result.status === 'fulfilled') {
                papers.push(...result.value);
            }
        });
        // Remove duplicates by DOI/PMID/arXivId
        return this.deduplicatePapers(papers);
    }
    /**
     * Generate AI summary for a paper (placeholder for AI integration)
     */
    async generateAISummary(paper) {
        // This would integrate with OpenAI/Together AI
        // Placeholder implementation
        return `AI Summary: This paper titled "${paper.title}" was published in ${paper.year}. ${paper.abstract ? paper.abstract.substring(0, 200) + '...' : 'Abstract not available.'}`;
    }
    /**
     * Extract key findings using AI (placeholder)
     */
    async extractKeyFindings(paper) {
        // This would use AI to analyze the paper
        // Placeholder implementation
        return [
            'Key finding 1 from the paper',
            'Key finding 2 from the paper',
            'Key finding 3 from the paper'
        ];
    }
    /**
     * Extract methodology using AI (placeholder)
     */
    async extractMethodology(paper) {
        // This would use AI to extract methodology
        // Placeholder implementation
        return 'Methodology: The study employed...';
    }
    /**
     * Calculate relevance to user's work (placeholder)
     */
    async calculateRelevance(paper, userProfile) {
        // This would use AI to match paper to user's research interests
        // Returns score 0-100
        // Placeholder implementation
        return Math.floor(Math.random() * 100);
    }
    // Helper methods
    isDOI(str) {
        return /^(https?:\/\/)?(dx\.)?doi\.org\/10\.\d+/i.test(str) ||
            /^10\.\d+\/.+/.test(str);
    }
    isPMID(str) {
        return /^\d{7,8}$/.test(str.trim()) ||
            /pmid:?\s*\d{7,8}/i.test(str);
    }
    isArXivId(str) {
        return /^(arxiv:)?(\d{4}\.\d{4,5}|[a-z-]+\/\d{7})(v\d+)?$/i.test(str) ||
            /arxiv\.org\/abs\//i.test(str);
    }
    deduplicatePapers(papers) {
        const seen = new Set();
        return papers.filter(paper => {
            const key = paper.doi || paper.pmid || paper.arxivId || paper.title;
            if (seen.has(key))
                return false;
            seen.add(key);
            return true;
        });
    }
}
// Export singleton instance
export const paperFetchingService = new PaperFetchingService();
//# sourceMappingURL=doiIntegration.js.map