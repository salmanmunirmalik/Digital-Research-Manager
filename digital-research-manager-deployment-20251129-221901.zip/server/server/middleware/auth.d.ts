import type { Request, Response, NextFunction } from 'express';
export interface AuthenticatedUser {
    id: string;
    username: string;
    email: string;
    role: string;
    status?: string;
    first_name?: string;
    last_name?: string;
}
export interface AuthenticatedRequest extends Request {
    user?: AuthenticatedUser;
}
export declare const authenticateToken: (req: AuthenticatedRequest, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
export declare const requireRole: (roles: string[]) => (req: AuthenticatedRequest, res: Response, next: NextFunction) => void | Response<any, Record<string, any>>;
export declare const demoAuth: (req: AuthenticatedRequest, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
//# sourceMappingURL=auth.d.ts.map