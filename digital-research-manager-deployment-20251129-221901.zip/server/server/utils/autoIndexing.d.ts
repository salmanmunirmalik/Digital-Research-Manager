/**
 * Auto-Indexing Utility for AI Learning
 * Automatically indexes user content for AI training
 */
/**
 * Auto-index content for AI learning
 */
export declare function autoIndexContent(userId: string, sourceType: string, sourceId: string, data: any): Promise<void>;
/**
 * Auto-index multiple content items
 */
export declare function autoIndexMultiple(userId: string, sourceType: string, items: Array<{
    id: string;
    data: any;
}>): Promise<void>;
declare const _default: {
    autoIndexContent: typeof autoIndexContent;
    autoIndexMultiple: typeof autoIndexMultiple;
};
export default _default;
//# sourceMappingURL=autoIndexing.d.ts.map