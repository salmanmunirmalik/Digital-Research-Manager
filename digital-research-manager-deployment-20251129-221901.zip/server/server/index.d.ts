import { type Application } from 'express';
declare const app: Application;
declare global {
    namespace Express {
        interface Request {
            user?: any;
        }
    }
}
export default app;
//# sourceMappingURL=index.d.ts.map