import express from 'express';
import { Pool } from 'pg';
export declare function setupResearchDashboardRoutes(app: express.Application, pool: Pool): express.Application;
export declare function runResearchDashboardMigration(pool: Pool): Promise<void>;
export declare function generateSampleResearchData(pool: Pool, labId: string, userId: string): Promise<void>;
export declare function checkResearchDashboardHealth(pool: Pool): Promise<{
    status: string;
    tables: {};
    functions: {};
    timestamp: string;
} | {
    status: string;
    error: any;
    timestamp: string;
}>;
declare const _default: {
    setupResearchDashboardRoutes: typeof setupResearchDashboardRoutes;
    runResearchDashboardMigration: typeof runResearchDashboardMigration;
    generateSampleResearchData: typeof generateSampleResearchData;
    checkResearchDashboardHealth: typeof checkResearchDashboardHealth;
};
export default _default;
//# sourceMappingURL=researchDashboardSetup.d.ts.map