export default AIPresentationService;
declare class AIPresentationService {
    openaiApiKey: string | undefined;
    baseURL: string;
    timeout: number;
    generatePresentationOutline(topic: any, context: any, slides?: number): Promise<{
        success: boolean;
        outline: any;
    }>;
    generateSlideContent(slideTitle: any, slideContent: any, slideType: any, context?: string): Promise<{
        success: boolean;
        slideData: any;
    }>;
    generateFullPresentation(topic: any, context: any, slides?: number, theme?: string): Promise<{
        success: boolean;
        presentation: {
            title: any;
            theme: string;
            slides: never[];
            metadata: {
                generatedAt: string;
                totalSlides: any;
                context: any;
            };
        };
    }>;
    improvePresentationContent(presentationId: any, slideId: any, feedback: any, currentContent: any): Promise<{
        success: boolean;
        improvedContent: any;
    }>;
    validateApiKey(): boolean;
    getAvailableThemes(): {
        id: string;
        name: string;
        description: string;
        colors: {
            primary: string;
            secondary: string;
            accent: string;
            background: string;
            text: string;
        };
    }[];
}
//# sourceMappingURL=aiPresentationService.d.ts.map