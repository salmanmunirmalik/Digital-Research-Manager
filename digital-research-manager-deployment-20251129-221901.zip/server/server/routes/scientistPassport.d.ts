/**
 * Scientist Passport API Routes
 * Handles skills, certifications, availability, endorsements, and speaking profile
 */
import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=scientistPassport.d.ts.map