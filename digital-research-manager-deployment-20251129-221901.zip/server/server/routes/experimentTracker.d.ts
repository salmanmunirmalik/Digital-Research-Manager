import { Request, Response, Router } from 'express';
declare const router: Router;
export declare const getExperiments: (req: Request, res: Response) => Promise<void>;
export declare const getExperiment: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const createExperiment: (req: Request, res: Response) => Promise<void>;
export declare const updateExperiment: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const deleteExperiment: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getTemplates: (req: Request, res: Response) => Promise<void>;
export declare const createTemplate: (req: Request, res: Response) => Promise<void>;
export declare const addMilestone: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateMilestoneStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const addProgressLog: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getExperimentAnalytics: (req: Request, res: Response) => Promise<void>;
export default router;
//# sourceMappingURL=experimentTracker.d.ts.map