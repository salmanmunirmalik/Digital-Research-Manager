/**
 * The Scientist First Journal API Routes
 * Handles article submissions, reviews, and interactions
 */
import { type Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=scientistFirst.d.ts.map