// Enhanced Reference System API with Platform Activity Tracking
// Includes peer references + platform-generated references based on activities
import express from 'express';
import { pool } from '../index';
import { authenticateToken } from '../index';
const router = express.Router();
// Track platform activity (called when user creates lab notebook entries, protocols, etc.)
router.post('/track-activity', authenticateToken, async (req, res) => {
    try {
        const { activityType, activityTitle, activityDescription, activityData, skillsDemonstrated = [] } = req.body;
        const userId = req.user.id;
        // Analyze activity to generate scores
        const analysis = await analyzeActivity({
            activityType,
            activityTitle,
            activityDescription,
            activityData,
            skillsDemonstrated
        });
        // Insert activity
        const activityQuery = `
      INSERT INTO platform_activities (
        user_id, activity_type, activity_title, activity_description,
        activity_data, complexity_score, innovation_score,
        collaboration_score, documentation_quality, skills_demonstrated
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `;
        const result = await pool.query(activityQuery, [
            userId, activityType, activityTitle, activityDescription,
            JSON.stringify(activityData), analysis.complexity,
            analysis.innovation, analysis.collaboration,
            analysis.documentation, skillsDemonstrated
        ]);
        // Update user stats
        await updateUserActivityStats(userId);
        res.json({
            activity: result.rows[0],
            analysis: analysis,
            message: 'Activity tracked successfully'
        });
    }
    catch (error) {
        console.error('Error tracking activity:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Generate platform reference based on activities
router.post('/generate-platform-reference', authenticateToken, async (req, res) => {
    try {
        const { analysisPeriodMonths = 12 } = req.body;
        const userId = req.user.id;
        // Get activities from the specified period
        const activitiesQuery = `
      SELECT * FROM platform_activities
      WHERE user_id = $1
      AND created_at >= NOW() - INTERVAL '${analysisPeriodMonths} months'
      ORDER BY created_at DESC
    `;
        const activities = await pool.query(activitiesQuery, [userId]);
        if (activities.rows.length === 0) {
            return res.status(404).json({ error: 'No activities found for the specified period' });
        }
        // Generate platform reference
        const platformReference = await generatePlatformReference(activities.rows);
        // Save platform reference
        const referenceQuery = `
      INSERT INTO platform_references (
        user_id, reference_title, reference_text, overall_score,
        activities_analyzed, analysis_period_start, analysis_period_end,
        technical_skills, soft_skills, research_methodologies,
        total_activities, average_complexity, average_innovation,
        collaboration_frequency, documentation_consistency,
        ai_confidence_score, analysis_metadata
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
      RETURNING *
    `;
        const result = await pool.query(referenceQuery, [
            userId,
            platformReference.title,
            platformReference.text,
            platformReference.overallScore,
            activities.rows.map((a) => a.id),
            platformReference.periodStart,
            platformReference.periodEnd,
            platformReference.technicalSkills,
            platformReference.softSkills,
            platformReference.researchMethodologies,
            platformReference.totalActivities,
            platformReference.averageComplexity,
            platformReference.averageInnovation,
            platformReference.collaborationFrequency,
            platformReference.documentationConsistency,
            platformReference.confidence,
            JSON.stringify(platformReference.metadata)
        ]);
        res.json({
            platformReference: result.rows[0],
            activitiesAnalyzed: activities.rows.length,
            confidenceScore: platformReference.confidence
        });
    }
    catch (error) {
        console.error('Error generating platform reference:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Enhanced reference letter generation (combines peer + platform references)
router.post('/generate-comprehensive-letter', authenticateToken, async (req, res) => {
    try {
        const { jobTitle, companyName, jobDescription, requiredSkills = [], jobType = 'industry', includePlatformReference = true, includePeerReferences = true } = req.body;
        const userId = req.user.id;
        let peerReferences = [];
        let platformReferences = [];
        // Get peer references if requested
        if (includePeerReferences) {
            const peerQuery = `
        SELECT 
          rc.*,
          u.email as giver_email,
          u.first_name as giver_first_name,
          u.last_name as giver_last_name
        FROM reference_collections rc
        JOIN users u ON rc.reference_giver_id = u.id
        WHERE rc.user_id = $1
        AND (
          $2 = ANY(rc.skills_mentioned) OR
          rc.context_type = $3 OR
          rc.overall_rating >= 4
        )
        ORDER BY rc.overall_rating DESC, rc.created_at DESC
        LIMIT 5
      `;
            const peerResult = await pool.query(peerQuery, [
                userId,
                requiredSkills.length > 0 ? requiredSkills[0] : null,
                jobType
            ]);
            peerReferences = peerResult.rows;
        }
        // Get platform references if requested
        if (includePlatformReference) {
            const platformQuery = `
        SELECT * FROM platform_references
        WHERE user_id = $1
        ORDER BY created_at DESC
        LIMIT 3
      `;
            const platformResult = await pool.query(platformQuery, [userId]);
            platformReferences = platformResult.rows;
        }
        if (peerReferences.length === 0 && platformReferences.length === 0) {
            return res.status(404).json({ error: 'No references found' });
        }
        // Generate comprehensive reference letter
        const comprehensiveLetter = await generateComprehensiveReferenceLetter({
            jobTitle,
            companyName,
            jobDescription,
            requiredSkills,
            peerReferences,
            platformReferences
        });
        // Save job application
        const applicationQuery = `
      INSERT INTO job_applications (
        user_id, job_title, company_name, job_description,
        required_skills, job_type, matched_references,
        matched_platform_references, ai_generated_letter,
        platform_generated_letter, combined_reference_letter,
        peer_confidence_score, platform_confidence_score,
        overall_confidence_score
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
      RETURNING *
    `;
        const application = await pool.query(applicationQuery, [
            userId, jobTitle, companyName, jobDescription,
            requiredSkills, jobType,
            peerReferences.map((r) => r.id),
            platformReferences.map((r) => r.id),
            comprehensiveLetter.peerLetter,
            comprehensiveLetter.platformLetter,
            comprehensiveLetter.combinedLetter,
            comprehensiveLetter.peerConfidence,
            comprehensiveLetter.platformConfidence,
            comprehensiveLetter.overallConfidence
        ]);
        res.json({
            application: application.rows[0],
            peerReferences: peerReferences,
            platformReferences: platformReferences,
            comprehensiveLetter: comprehensiveLetter.combinedLetter,
            peerLetter: comprehensiveLetter.peerLetter,
            platformLetter: comprehensiveLetter.platformLetter,
            confidenceScores: {
                peer: comprehensiveLetter.peerConfidence,
                platform: comprehensiveLetter.platformConfidence,
                overall: comprehensiveLetter.overallConfidence
            }
        });
    }
    catch (error) {
        console.error('Error generating comprehensive letter:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Get user's platform activities
router.get('/activities', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const { limit = 20, offset = 0, activityType } = req.query;
        let query = `
      SELECT * FROM platform_activities
      WHERE user_id = $1
    `;
        const params = [userId];
        if (activityType) {
            query += ` AND activity_type = $2`;
            params.push(activityType);
        }
        query += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
        params.push(parseInt(limit), parseInt(offset));
        const result = await pool.query(query, params);
        res.json({ activities: result.rows });
    }
    catch (error) {
        console.error('Error fetching activities:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Get user's platform references
router.get('/platform-references', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const query = `
      SELECT * FROM platform_references
      WHERE user_id = $1
      ORDER BY created_at DESC
    `;
        const result = await pool.query(query, [userId]);
        res.json({ platformReferences: result.rows });
    }
    catch (error) {
        console.error('Error fetching platform references:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Get comprehensive user profile (peer + platform stats)
router.get('/comprehensive-profile', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const profileQuery = `
      SELECT 
        rs.*,
        u.email,
        u.first_name,
        u.last_name,
        COUNT(pa.id) as total_activities,
        COUNT(pr.id) as total_platform_references,
        AVG(pa.complexity_score) as avg_complexity,
        AVG(pa.innovation_score) as avg_innovation
      FROM user_reference_stats rs
      JOIN users u ON rs.user_id = u.id
      LEFT JOIN platform_activities pa ON rs.user_id = pa.user_id
      LEFT JOIN platform_references pr ON rs.user_id = pr.user_id
      WHERE rs.user_id = $1
      GROUP BY rs.id, u.email, u.first_name, u.last_name
    `;
        const result = await pool.query(profileQuery, [userId]);
        if (result.rows.length === 0) {
            // Create initial stats
            await pool.query('INSERT INTO user_reference_stats (user_id) VALUES ($1)', [userId]);
            res.json({
                profile: {
                    user_id: userId,
                    total_references: 0,
                    total_platform_references: 0,
                    average_rating: 0,
                    total_activities: 0
                },
                isNew: true
            });
        }
        else {
            res.json({ profile: result.rows[0], isNew: false });
        }
    }
    catch (error) {
        console.error('Error fetching comprehensive profile:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Helper function to analyze activity and generate scores
async function analyzeActivity({ activityType, activityTitle, activityDescription, activityData, skillsDemonstrated }) {
    // This would integrate with AI analysis
    // For now, we'll use simple heuristics
    let complexity = 2.0;
    let innovation = 2.0;
    let collaboration = 2.0;
    let documentation = 3.0;
    // Analyze based on activity type
    switch (activityType) {
        case 'lab_notebook_entry':
            complexity = activityDescription.length > 500 ? 4.0 : 3.0;
            documentation = 4.0;
            break;
        case 'protocol_created':
            complexity = 4.0;
            innovation = 3.5;
            documentation = 4.5;
            break;
        case 'experiment_completed':
            complexity = 3.5;
            innovation = 3.0;
            break;
        case 'paper_published':
            complexity = 5.0;
            innovation = 4.5;
            documentation = 5.0;
            break;
        case 'collaboration':
            collaboration = 4.5;
            break;
    }
    // Analyze based on skills demonstrated
    if (skillsDemonstrated.includes('machine_learning'))
        complexity += 0.5;
    if (skillsDemonstrated.includes('data_analysis'))
        complexity += 0.3;
    if (skillsDemonstrated.includes('leadership'))
        collaboration += 0.5;
    if (skillsDemonstrated.includes('writing'))
        documentation += 0.5;
    // Cap scores at 5.0
    return {
        complexity: Math.min(complexity, 5.0),
        innovation: Math.min(innovation, 5.0),
        collaboration: Math.min(collaboration, 5.0),
        documentation: Math.min(documentation, 5.0)
    };
}
// Helper function to generate platform reference
async function generatePlatformReference(activities) {
    const totalActivities = activities.length;
    const avgComplexity = activities.reduce((sum, a) => sum + a.complexity_score, 0) / totalActivities;
    const avgInnovation = activities.reduce((sum, a) => sum + a.innovation_score, 0) / totalActivities;
    const avgCollaboration = activities.reduce((sum, a) => sum + a.collaboration_score, 0) / totalActivities;
    const avgDocumentation = activities.reduce((sum, a) => sum + a.documentation_quality, 0) / totalActivities;
    // Extract skills
    const allSkills = activities.flatMap(a => a.skills_demonstrated || []);
    const skillCounts = allSkills.reduce((acc, skill) => {
        acc[skill] = (acc[skill] || 0) + 1;
        return acc;
    }, {});
    const topSkills = Object.entries(skillCounts)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 10)
        .map(([skill]) => skill);
    // Generate reference text
    const overallScore = (avgComplexity + avgInnovation + avgCollaboration + avgDocumentation) / 4;
    const referenceText = `
Based on comprehensive analysis of ${totalActivities} platform activities over the past 12 months, I can attest to this candidate's exceptional capabilities:

**Technical Excellence**: The candidate demonstrates strong technical skills with an average complexity score of ${avgComplexity.toFixed(1)}/5.0 across ${totalActivities} documented activities, including ${activities.filter(a => a.activity_type === 'protocol_created').length} protocol creations and ${activities.filter(a => a.activity_type === 'experiment_completed').length} completed experiments.

**Innovation & Research**: With an innovation score of ${avgInnovation.toFixed(1)}/5.0, the candidate shows consistent creative problem-solving and research excellence. Their work spans multiple domains including ${topSkills.slice(0, 5).join(', ')}.

**Collaboration & Communication**: The candidate's collaboration score of ${avgCollaboration.toFixed(1)}/5.0 reflects strong teamwork abilities and effective communication skills, essential for modern research environments.

**Documentation & Methodology**: Exceptional documentation quality (${avgDocumentation.toFixed(1)}/5.0) demonstrates meticulous attention to detail and adherence to scientific standards.

**Key Strengths**:
${topSkills.slice(0, 5).map(skill => `• Expert-level proficiency in ${skill}`).join('\n')}

**Notable Achievements**:
${activities.filter(a => a.innovation_score >= 4).slice(0, 3).map(a => `• ${a.activity_title} (Innovation Score: ${a.innovation_score}/5.0)`).join('\n')}

This comprehensive analysis, based on ${totalActivities} documented activities, provides objective evidence of the candidate's capabilities and work ethic. I strongly recommend them for positions requiring technical excellence, research innovation, and collaborative skills.

**Overall Platform Assessment**: ${overallScore.toFixed(1)}/5.0
**Analysis Confidence**: ${Math.min(0.9, 0.6 + (totalActivities * 0.02))} (based on ${totalActivities} activities analyzed)
  `;
    return {
        title: `Platform Activity Analysis (${totalActivities} activities)`,
        text: referenceText.trim(),
        overallScore: overallScore,
        periodStart: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        periodEnd: new Date().toISOString().split('T')[0],
        technicalSkills: topSkills.filter(skill => ['python', 'machine_learning', 'data_analysis', 'statistics', 'programming'].includes(skill)),
        softSkills: topSkills.filter(skill => ['leadership', 'communication', 'teamwork', 'problem_solving'].includes(skill)),
        researchMethodologies: topSkills.filter(skill => ['experimental_design', 'statistical_analysis', 'data_collection', 'hypothesis_testing'].includes(skill)),
        totalActivities: totalActivities,
        averageComplexity: avgComplexity,
        averageInnovation: avgInnovation,
        collaborationFrequency: avgCollaboration,
        documentationConsistency: avgDocumentation,
        confidence: Math.min(0.95, 0.7 + (totalActivities * 0.01)),
        metadata: {
            activityTypes: [...new Set(activities.map(a => a.activity_type))],
            skillDistribution: skillCounts,
            timeDistribution: activities.reduce((acc, a) => {
                const month = new Date(a.created_at).toISOString().substring(0, 7);
                acc[month] = (acc[month] || 0) + 1;
                return acc;
            }, {})
        }
    };
}
// Helper function to generate comprehensive reference letter
async function generateComprehensiveReferenceLetter({ jobTitle, companyName, jobDescription, requiredSkills, peerReferences, platformReferences }) {
    // Generate peer-based letter
    const peerLetter = peerReferences.length > 0 ?
        await generateAIReferenceLetter({ jobTitle, companyName, jobDescription, requiredSkills, references: peerReferences }) :
        { text: 'No peer references available for this application.', confidence: 0 };
    // Generate platform-based letter
    const platformLetter = platformReferences.length > 0 ?
        platformReferences[0].reference_text :
        'No platform activity analysis available for this application.';
    // Generate combined letter
    const combinedLetter = `
**COMPREHENSIVE REFERENCE LETTER**

**To Whom It May Concern,**

I am writing to provide a comprehensive recommendation for this candidate for the position of ${jobTitle} at ${companyName}. This recommendation is based on two complementary sources: peer references from professional colleagues and collaborators, and objective analysis of their documented platform activities.

---

**PEER REFERENCE SUMMARY**
${peerReferences.length > 0 ? peerLetter.text : 'No peer references available.'}

---

**PLATFORM ACTIVITY ANALYSIS**
${platformReferences.length > 0 ? platformReferences[0].reference_text : 'No platform activity analysis available.'}

---

**COMBINED ASSESSMENT**

This dual-source approach provides a complete picture of the candidate's capabilities:
- **Peer perspectives** offer insights into interpersonal skills, collaboration, and professional relationships
- **Platform analysis** provides objective evidence of technical skills, work consistency, and methodological rigor

The combination of positive peer feedback and strong platform activity metrics demonstrates a well-rounded candidate who excels both in technical execution and professional collaboration.

**Overall Recommendation**: I strongly recommend this candidate for the ${jobTitle} position at ${companyName}. Their combination of peer-validated interpersonal skills and objectively-demonstrated technical capabilities makes them an ideal fit for this role.

**Confidence Levels**:
- Peer References: ${(peerLetter.confidence * 100).toFixed(1)}%
- Platform Analysis: ${platformReferences.length > 0 ? (platformReferences[0].ai_confidence_score * 100).toFixed(1) : 0}%
- Combined Assessment: ${((peerLetter.confidence + (platformReferences.length > 0 ? platformReferences[0].ai_confidence_score : 0)) / 2 * 100).toFixed(1)}%

Sincerely,
AI-Generated Comprehensive Reference System
  `;
    return {
        peerLetter: peerLetter.text,
        platformLetter: platformLetter,
        combinedLetter: combinedLetter.trim(),
        peerConfidence: peerLetter.confidence,
        platformConfidence: platformReferences.length > 0 ? platformReferences[0].ai_confidence_score : 0,
        overallConfidence: (peerLetter.confidence + (platformReferences.length > 0 ? platformReferences[0].ai_confidence_score : 0)) / 2
    };
}
// Helper function to update user activity stats
async function updateUserActivityStats(userId) {
    try {
        const statsQuery = `
      SELECT 
        COUNT(*) as total_activities,
        AVG(complexity_score + innovation_score + collaboration_score + documentation_quality) / 4 as avg_score
      FROM platform_activities
      WHERE user_id = $1
    `;
        const stats = await pool.query(statsQuery, [userId]);
        const statsData = stats.rows[0];
        await pool.query(`
      UPDATE user_reference_stats 
      SET 
        total_activities = $2,
        average_activity_score = $3,
        last_updated = CURRENT_TIMESTAMP
      WHERE user_id = $1
    `, [userId, statsData.total_activities, statsData.avg_score || 0]);
    }
    catch (error) {
        console.error('Error updating user activity stats:', error);
    }
}
// Import the existing generateAIReferenceLetter function
async function generateAIReferenceLetter({ jobTitle, companyName, jobDescription, requiredSkills, references }) {
    // ... existing implementation from previous file
    return { text: 'Generated peer reference letter', confidence: 0.8 };
}
export default router;
//# sourceMappingURL=enhancedReferences.js.map