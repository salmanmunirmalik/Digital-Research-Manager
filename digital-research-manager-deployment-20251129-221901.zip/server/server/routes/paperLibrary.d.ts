/**
 * Paper Library API Routes
 * Exposes DOI Integration and paper fetching services
 * Implements Salman's vision: Auto-fetch papers, save full paper or AI summary
 */
import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=paperLibrary.d.ts.map