/**
 * Settings API Routes
 * User settings and preferences management
 */
import { type Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=settings.d.ts.map