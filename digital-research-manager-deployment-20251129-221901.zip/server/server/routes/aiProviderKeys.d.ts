/**
 * AI Provider API Keys Management Routes
 * Allow users to add their own API keys for OpenAI, Gemini, CoPilot, Perplexity, etc.
 */
import { type Router } from 'express';
declare const router: Router;
export declare function getUserApiKey(userId: string, provider: string): Promise<string | null>;
export declare function getUserDefaultProvider(userId: string, type: 'embedding' | 'chat'): Promise<string>;
export default router;
//# sourceMappingURL=aiProviderKeys.d.ts.map