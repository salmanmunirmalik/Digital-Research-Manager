import { type Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=crossEntityIntegration.d.ts.map