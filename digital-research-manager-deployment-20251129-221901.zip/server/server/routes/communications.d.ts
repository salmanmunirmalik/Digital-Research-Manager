/**
 * Unified Communications API Routes
 * Centralized communication system for all user interactions
 */
import { type Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=communications.d.ts.map