/**
 * Project Management & PI Review API Routes
 * Team hierarchy, work packages, progress reports, PI reviews
 */
import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=projectManagement.d.ts.map