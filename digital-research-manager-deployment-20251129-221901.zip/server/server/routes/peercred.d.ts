import { type Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=peercred.d.ts.map