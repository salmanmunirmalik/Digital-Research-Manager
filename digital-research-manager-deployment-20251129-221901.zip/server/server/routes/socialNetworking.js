// Social Networking API Routes
// Comprehensive social features: connections, follows, profile sharing, networking
import express from 'express';
import { pool } from '../index';
import { authenticateToken } from '../index';
import crypto from 'crypto';
const router = express.Router();
// ==============================================
// USER PROFILES & SOCIAL SETTINGS
// ==============================================
// Get user social profile
router.get('/profile/:userId', authenticateToken, async (req, res) => {
    try {
        const { userId } = req.params;
        const currentUserId = req.user.id;
        // Check if user exists and get basic info
        const userQuery = `
      SELECT u.id, u.email, u.first_name, u.last_name, u.role, u.created_at
      FROM users u
      WHERE u.id = $1
    `;
        const userResult = await pool.query(userQuery, [userId]);
        if (userResult.rows.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        const user = userResult.rows[0];
        // Get social profile
        const profileQuery = `
      SELECT * FROM user_social_profiles
      WHERE user_id = $1
    `;
        const profileResult = await pool.query(profileQuery, [userId]);
        const profile = profileResult.rows[0];
        // Check connection status
        const connectionQuery = `
      SELECT status FROM user_connections
      WHERE (requester_id = $1 AND receiver_id = $2) OR (requester_id = $2 AND receiver_id = $1)
    `;
        const connectionResult = await pool.query(connectionQuery, [currentUserId, userId]);
        const connectionStatus = connectionResult.rows[0]?.status || 'none';
        // Check follow status
        const followQuery = `
      SELECT status FROM user_follows
      WHERE follower_id = $1 AND following_id = $2
    `;
        const followResult = await pool.query(followQuery, [currentUserId, userId]);
        const followStatus = followResult.rows[0]?.status || 'none';
        // Get recent activities (if profile is public or connected)
        let activities = [];
        if (profile?.profile_visibility === 'public' || connectionStatus === 'accepted') {
            const activitiesQuery = `
        SELECT * FROM social_activities
        WHERE user_id = $1
        ORDER BY created_at DESC
        LIMIT 10
      `;
            const activitiesResult = await pool.query(activitiesQuery, [userId]);
            activities = activitiesResult.rows;
        }
        res.json({
            user: {
                id: user.id,
                email: profile?.show_email ? user.email : null,
                firstName: user.first_name,
                lastName: user.last_name,
                role: user.role,
                createdAt: user.created_at
            },
            profile: profile,
            connectionStatus: connectionStatus,
            followStatus: followStatus,
            activities: activities
        });
    }
    catch (error) {
        console.error('Error fetching user profile:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Update user social profile
router.put('/profile', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const { bio, profilePictureUrl, coverPhotoUrl, websiteUrl, linkedinUrl, twitterUrl, orcidId, googleScholarUrl, location, timezone, currentPosition, currentInstitution, researchInterests, expertiseAreas, languages, profileVisibility, showEmail, showPhone, showLocation, showResearchInterests, showPublications, showConnectionsCount, allowConnectionRequests, allowFollowRequests, allowProfileSharing, allowReferenceRequests } = req.body;
        // Upsert social profile
        const upsertQuery = `
      INSERT INTO user_social_profiles (
        user_id, bio, profile_picture_url, cover_photo_url, website_url,
        linkedin_url, twitter_url, orcid_id, google_scholar_url, location,
        timezone, current_position, current_institution, research_interests,
        expertise_areas, languages, profile_visibility, show_email, show_phone,
        show_location, show_research_interests, show_publications,
        show_connections_count, allow_connection_requests, allow_follow_requests,
        allow_profile_sharing, allow_reference_requests
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27)
      ON CONFLICT (user_id) DO UPDATE SET
        bio = EXCLUDED.bio,
        profile_picture_url = EXCLUDED.profile_picture_url,
        cover_photo_url = EXCLUDED.cover_photo_url,
        website_url = EXCLUDED.website_url,
        linkedin_url = EXCLUDED.linkedin_url,
        twitter_url = EXCLUDED.twitter_url,
        orcid_id = EXCLUDED.orcid_id,
        google_scholar_url = EXCLUDED.google_scholar_url,
        location = EXCLUDED.location,
        timezone = EXCLUDED.timezone,
        current_position = EXCLUDED.current_position,
        current_institution = EXCLUDED.current_institution,
        research_interests = EXCLUDED.research_interests,
        expertise_areas = EXCLUDED.expertise_areas,
        languages = EXCLUDED.languages,
        profile_visibility = EXCLUDED.profile_visibility,
        show_email = EXCLUDED.show_email,
        show_phone = EXCLUDED.show_phone,
        show_location = EXCLUDED.show_location,
        show_research_interests = EXCLUDED.show_research_interests,
        show_publications = EXCLUDED.show_publications,
        show_connections_count = EXCLUDED.show_connections_count,
        allow_connection_requests = EXCLUDED.allow_connection_requests,
        allow_follow_requests = EXCLUDED.allow_follow_requests,
        allow_profile_sharing = EXCLUDED.allow_profile_sharing,
        allow_reference_requests = EXCLUDED.allow_reference_requests,
        updated_at = CURRENT_TIMESTAMP
      RETURNING *
    `;
        const result = await pool.query(upsertQuery, [
            userId, bio, profilePictureUrl, coverPhotoUrl, websiteUrl,
            linkedinUrl, twitterUrl, orcidId, googleScholarUrl, location,
            timezone, currentPosition, currentInstitution, researchInterests,
            expertiseAreas, languages, profileVisibility, showEmail, showPhone,
            showLocation, showResearchInterests, showPublications,
            showConnectionsCount, allowConnectionRequests, allowFollowRequests,
            allowProfileSharing, allowReferenceRequests
        ]);
        res.json({
            profile: result.rows[0],
            message: 'Profile updated successfully'
        });
    }
    catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// ==============================================
// CONNECTION SYSTEM
// ==============================================
// Send connection request
router.post('/connections/request', authenticateToken, async (req, res) => {
    try {
        const { receiverId, connectionType, relationshipContext, requestMessage } = req.body;
        const requesterId = req.user.id;
        if (requesterId === receiverId) {
            return res.status(400).json({ error: 'Cannot connect to yourself' });
        }
        // Check if user exists
        const userCheck = await pool.query('SELECT id FROM users WHERE id = $1', [receiverId]);
        if (userCheck.rows.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        // Check if connection already exists
        const existingQuery = `
      SELECT status FROM user_connections
      WHERE (requester_id = $1 AND receiver_id = $2) OR (requester_id = $2 AND receiver_id = $1)
    `;
        const existingResult = await pool.query(existingQuery, [requesterId, receiverId]);
        if (existingResult.rows.length > 0) {
            return res.status(400).json({ error: 'Connection already exists' });
        }
        // Check if receiver allows connection requests
        const profileQuery = `
      SELECT allow_connection_requests FROM user_social_profiles
      WHERE user_id = $1
    `;
        const profileResult = await pool.query(profileQuery, [receiverId]);
        if (profileResult.rows.length > 0 && !profileResult.rows[0].allow_connection_requests) {
            return res.status(403).json({ error: 'User does not accept connection requests' });
        }
        // Create connection request
        const insertQuery = `
      INSERT INTO user_connections (
        requester_id, receiver_id, connection_type, relationship_context, request_message
      ) VALUES ($1, $2, $3, $4, $5)
      RETURNING *
    `;
        const result = await pool.query(insertQuery, [
            requesterId, receiverId, connectionType, relationshipContext, requestMessage
        ]);
        // Create notification
        await pool.query(`
      INSERT INTO user_notifications (
        user_id, notification_type, title, message, source_user_id, source_entity_type, source_entity_id
      ) VALUES ($1, 'connection_request', 'New Connection Request', 
        $2 || ' wants to connect with you', $3, 'connection', $4)
    `, [receiverId, req.user.first_name + ' ' + req.user.last_name, requesterId, result.rows[0].id]);
        res.json({
            connection: result.rows[0],
            message: 'Connection request sent successfully'
        });
    }
    catch (error) {
        console.error('Error sending connection request:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Respond to connection request
router.put('/connections/:connectionId/respond', authenticateToken, async (req, res) => {
    try {
        const { connectionId } = req.params;
        const { status, responseMessage } = req.body;
        const userId = req.user.id;
        // Get connection details
        const connectionQuery = `
      SELECT * FROM user_connections
      WHERE id = $1 AND receiver_id = $2
    `;
        const connectionResult = await pool.query(connectionQuery, [connectionId, userId]);
        if (connectionResult.rows.length === 0) {
            return res.status(404).json({ error: 'Connection request not found' });
        }
        const connection = connectionResult.rows[0];
        // Update connection status
        const updateQuery = `
      UPDATE user_connections
      SET status = $1, response_message = $2, confirmed_at = $3, updated_at = CURRENT_TIMESTAMP
      WHERE id = $4
      RETURNING *
    `;
        const confirmedAt = status === 'accepted' ? new Date() : null;
        const result = await pool.query(updateQuery, [status, responseMessage, confirmedAt, connectionId]);
        // Create notification for requester
        const notificationMessage = status === 'accepted'
            ? 'accepted your connection request'
            : 'declined your connection request';
        await pool.query(`
      INSERT INTO user_notifications (
        user_id, notification_type, title, message, source_user_id, source_entity_type, source_entity_id
      ) VALUES ($1, 'connection_response', 'Connection Request ' + $2, 
        $3 || ' ' || $4, $5, 'connection', $6)
    `, [connection.requester_id, status, req.user.first_name + ' ' + req.user.last_name, notificationMessage, userId, connectionId]);
        res.json({
            connection: result.rows[0],
            message: `Connection request ${status} successfully`
        });
    }
    catch (error) {
        console.error('Error responding to connection request:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Get user connections
router.get('/connections', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const { status = 'accepted', limit = 50, offset = 0 } = req.query;
        const query = `
      SELECT 
        uc.*,
        CASE 
          WHEN uc.requester_id = $1 THEN u2.first_name || ' ' || u2.last_name
          ELSE u1.first_name || ' ' || u1.last_name
        END as connection_name,
        CASE 
          WHEN uc.requester_id = $1 THEN u2.email
          ELSE u1.email
        END as connection_email,
        CASE 
          WHEN uc.requester_id = $1 THEN usp2.current_position
          ELSE usp1.current_position
        END as connection_position,
        CASE 
          WHEN uc.requester_id = $1 THEN usp2.current_institution
          ELSE usp1.current_institution
        END as connection_institution
      FROM user_connections uc
      LEFT JOIN users u1 ON uc.requester_id = u1.id
      LEFT JOIN users u2 ON uc.receiver_id = u2.id
      LEFT JOIN user_social_profiles usp1 ON uc.requester_id = usp1.user_id
      LEFT JOIN user_social_profiles usp2 ON uc.receiver_id = usp2.user_id
      WHERE (uc.requester_id = $1 OR uc.receiver_id = $1)
      AND uc.status = $2
      ORDER BY uc.created_at DESC
      LIMIT $3 OFFSET $4
    `;
        const result = await pool.query(query, [userId, status, parseInt(limit), parseInt(offset)]);
        res.json({ connections: result.rows });
    }
    catch (error) {
        console.error('Error fetching connections:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// ==============================================
// FOLLOW SYSTEM
// ==============================================
// Follow user
router.post('/follow', authenticateToken, async (req, res) => {
    try {
        const { followingId, followType = 'general' } = req.body;
        const followerId = req.user.id;
        if (followerId === followingId) {
            return res.status(400).json({ error: 'Cannot follow yourself' });
        }
        // Check if user exists
        const userCheck = await pool.query('SELECT id FROM users WHERE id = $1', [followingId]);
        if (userCheck.rows.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        // Check if already following
        const existingQuery = `
      SELECT status FROM user_follows
      WHERE follower_id = $1 AND following_id = $2
    `;
        const existingResult = await pool.query(existingQuery, [followerId, followingId]);
        if (existingResult.rows.length > 0) {
            return res.status(400).json({ error: 'Already following this user' });
        }
        // Check if user allows follow requests
        const profileQuery = `
      SELECT allow_follow_requests FROM user_social_profiles
      WHERE user_id = $1
    `;
        const profileResult = await pool.query(profileQuery, [followingId]);
        if (profileResult.rows.length > 0 && !profileResult.rows[0].allow_follow_requests) {
            return res.status(403).json({ error: 'User does not accept follow requests' });
        }
        // Create follow relationship
        const insertQuery = `
      INSERT INTO user_follows (follower_id, following_id, follow_type)
      VALUES ($1, $2, $3)
      RETURNING *
    `;
        const result = await pool.query(insertQuery, [followerId, followingId, followType]);
        // Create notification
        await pool.query(`
      INSERT INTO user_notifications (
        user_id, notification_type, title, message, source_user_id, source_entity_type, source_entity_id
      ) VALUES ($1, 'follow', 'New Follower', 
        $2 || ' started following you', $3, 'follow', $4)
    `, [followingId, req.user.first_name + ' ' + req.user.last_name, followerId, result.rows[0].id]);
        res.json({
            follow: result.rows[0],
            message: 'Successfully started following user'
        });
    }
    catch (error) {
        console.error('Error following user:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Unfollow user
router.delete('/follow/:followingId', authenticateToken, async (req, res) => {
    try {
        const { followingId } = req.params;
        const followerId = req.user.id;
        const deleteQuery = `
      DELETE FROM user_follows
      WHERE follower_id = $1 AND following_id = $2
      RETURNING *
    `;
        const result = await pool.query(deleteQuery, [followerId, followingId]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Follow relationship not found' });
        }
        res.json({ message: 'Successfully unfollowed user' });
    }
    catch (error) {
        console.error('Error unfollowing user:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Get followers/following
router.get('/follows', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const { type = 'followers', limit = 50, offset = 0 } = req.query;
        let query;
        if (type === 'followers') {
            query = `
        SELECT 
          uf.*,
          u.first_name || ' ' || u.last_name as follower_name,
          u.email as follower_email,
          usp.current_position as follower_position,
          usp.current_institution as follower_institution
        FROM user_follows uf
        JOIN users u ON uf.follower_id = u.id
        LEFT JOIN user_social_profiles usp ON uf.follower_id = usp.user_id
        WHERE uf.following_id = $1 AND uf.status = 'active'
        ORDER BY uf.created_at DESC
        LIMIT $2 OFFSET $3
      `;
        }
        else {
            query = `
        SELECT 
          uf.*,
          u.first_name || ' ' || u.last_name as following_name,
          u.email as following_email,
          usp.current_position as following_position,
          usp.current_institution as following_institution
        FROM user_follows uf
        JOIN users u ON uf.following_id = u.id
        LEFT JOIN user_social_profiles usp ON uf.following_id = usp.user_id
        WHERE uf.follower_id = $1 AND uf.status = 'active'
        ORDER BY uf.created_at DESC
        LIMIT $2 OFFSET $3
      `;
        }
        const result = await pool.query(query, [userId, parseInt(limit), parseInt(offset)]);
        res.json({ [type]: result.rows });
    }
    catch (error) {
        console.error('Error fetching follows:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// ==============================================
// PROFILE SHARING SYSTEM
// ==============================================
// Create profile share link
router.post('/profile/share', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const { shareType = 'public', password, expiresAt, maxViews, allowProfileView = true, allowPublicationsView = true, allowConnectionsView = false, allowContactInfo = false, allowReferenceRequest = true, customMessage } = req.body;
        // Check if user allows profile sharing
        const profileQuery = `
      SELECT allow_profile_sharing FROM user_social_profiles
      WHERE user_id = $1
    `;
        const profileResult = await pool.query(profileQuery, [userId]);
        if (profileResult.rows.length > 0 && !profileResult.rows[0].allow_profile_sharing) {
            return res.status(403).json({ error: 'Profile sharing is disabled' });
        }
        // Generate unique share token
        const shareToken = crypto.randomBytes(32).toString('hex');
        // Hash password if provided
        const passwordHash = password ? crypto.createHash('sha256').update(password).digest('hex') : null;
        // Create share link
        const insertQuery = `
      INSERT INTO profile_shares (
        user_id, share_token, share_type, password_hash, expires_at, max_views,
        allow_profile_view, allow_publications_view, allow_connections_view,
        allow_contact_info, allow_reference_request, custom_message
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `;
        const result = await pool.query(insertQuery, [
            userId, shareToken, shareType, passwordHash, expiresAt, maxViews,
            allowProfileView, allowPublicationsView, allowConnectionsView,
            allowContactInfo, allowReferenceRequest, customMessage
        ]);
        res.json({
            share: result.rows[0],
            shareUrl: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/profile/shared/${shareToken}`,
            message: 'Profile share link created successfully'
        });
    }
    catch (error) {
        console.error('Error creating profile share:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Get shared profile
router.get('/profile/shared/:shareToken', async (req, res) => {
    try {
        const { shareToken } = req.params;
        const { password } = req.query;
        // Get share details
        const shareQuery = `
      SELECT ps.*, u.first_name, u.last_name, u.email, u.role
      FROM profile_shares ps
      JOIN users u ON ps.user_id = u.id
      WHERE ps.share_token = $1 AND ps.is_active = true
    `;
        const shareResult = await pool.query(shareQuery, [shareToken]);
        if (shareResult.rows.length === 0) {
            return res.status(404).json({ error: 'Share link not found or expired' });
        }
        const share = shareResult.rows[0];
        // Check if share is expired
        if (share.expires_at && new Date(share.expires_at) < new Date()) {
            return res.status(410).json({ error: 'Share link has expired' });
        }
        // Check if max views reached
        if (share.max_views && share.current_views >= share.max_views) {
            return res.status(410).json({ error: 'Share link has reached maximum views' });
        }
        // Check password if required
        if (share.share_type === 'password_protected') {
            if (!password) {
                return res.status(401).json({ error: 'Password required' });
            }
            const passwordHash = crypto.createHash('sha256').update(password).digest('hex');
            if (passwordHash !== share.password_hash) {
                return res.status(401).json({ error: 'Invalid password' });
            }
        }
        // Increment view count
        await pool.query(`
      UPDATE profile_shares 
      SET current_views = current_views + 1
      WHERE id = $1
    `, [share.id]);
        // Record view
        await pool.query(`
      INSERT INTO profile_share_views (share_id, viewer_ip, viewer_user_agent)
      VALUES ($1, $2, $3)
    `, [share.id, req.ip, req.get('User-Agent')]);
        // Get user profile based on permissions
        const profileQuery = `
      SELECT * FROM user_social_profiles
      WHERE user_id = $1
    `;
        const profileResult = await pool.query(profileQuery, [share.user_id]);
        const profile = profileResult.rows[0];
        // Filter profile data based on permissions
        const filteredProfile = {
            id: share.user_id,
            firstName: share.first_name,
            lastName: share.last_name,
            email: share.allow_contact_info ? share.email : null,
            role: share.role,
            bio: share.allow_profile_view ? profile?.bio : null,
            currentPosition: share.allow_profile_view ? profile?.current_position : null,
            currentInstitution: share.allow_profile_view ? profile?.current_institution : null,
            researchInterests: share.allow_profile_view ? profile?.research_interests : null,
            expertiseAreas: share.allow_profile_view ? profile?.expertise_areas : null,
            websiteUrl: share.allow_profile_view ? profile?.website_url : null,
            linkedinUrl: share.allow_profile_view ? profile?.linkedin_url : null,
            orcidId: share.allow_profile_view ? profile?.orcid_id : null,
            customMessage: share.custom_message
        };
        res.json({
            profile: filteredProfile,
            share: {
                shareType: share.share_type,
                allowReferenceRequest: share.allow_reference_request,
                expiresAt: share.expires_at,
                maxViews: share.max_views,
                currentViews: share.current_views + 1
            }
        });
    }
    catch (error) {
        console.error('Error fetching shared profile:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Get user's share links
router.get('/profile/shares', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const query = `
      SELECT * FROM profile_shares
      WHERE user_id = $1
      ORDER BY created_at DESC
    `;
        const result = await pool.query(query, [userId]);
        // Add share URLs
        const shares = result.rows.map((share) => ({
            ...share,
            shareUrl: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/profile/shared/${share.share_token}`
        }));
        res.json({ shares });
    }
    catch (error) {
        console.error('Error fetching share links:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// ==============================================
// NOTIFICATIONS
// ==============================================
// Get user notifications
router.get('/notifications', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const { limit = 20, offset = 0, unreadOnly = false } = req.query;
        let query = `
      SELECT 
        un.*,
        u.first_name || ' ' || u.last_name as source_user_name
      FROM user_notifications un
      LEFT JOIN users u ON un.source_user_id = u.id
      WHERE un.user_id = $1
    `;
        const params = [userId];
        if (unreadOnly === 'true') {
            query += ` AND un.is_read = false`;
        }
        query += ` ORDER BY un.created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
        params.push(parseInt(limit), parseInt(offset));
        const result = await pool.query(query, params);
        res.json({ notifications: result.rows });
    }
    catch (error) {
        console.error('Error fetching notifications:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Mark notification as read
router.put('/notifications/:notificationId/read', authenticateToken, async (req, res) => {
    try {
        const { notificationId } = req.params;
        const userId = req.user.id;
        const updateQuery = `
      UPDATE user_notifications
      SET is_read = true, read_at = CURRENT_TIMESTAMP
      WHERE id = $1 AND user_id = $2
      RETURNING *
    `;
        const result = await pool.query(updateQuery, [notificationId, userId]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Notification not found' });
        }
        res.json({ notification: result.rows[0] });
    }
    catch (error) {
        console.error('Error marking notification as read:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Mark all notifications as read
router.put('/notifications/read-all', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const updateQuery = `
      UPDATE user_notifications
      SET is_read = true, read_at = CURRENT_TIMESTAMP
      WHERE user_id = $1 AND is_read = false
    `;
        await pool.query(updateQuery, [userId]);
        res.json({ message: 'All notifications marked as read' });
    }
    catch (error) {
        console.error('Error marking all notifications as read:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// ==============================================
// SEARCH & DISCOVERY
// ==============================================
// Search users
router.get('/search', authenticateToken, async (req, res) => {
    try {
        const { q, limit = 20, offset = 0 } = req.query;
        if (!q || q.length < 2) {
            return res.status(400).json({ error: 'Search query must be at least 2 characters' });
        }
        const searchQuery = `
      SELECT 
        u.id, u.first_name, u.last_name, u.email, u.role,
        usp.current_position, usp.current_institution, usp.research_interests,
        usp.profile_visibility, usp.connections_count, usp.followers_count
      FROM users u
      LEFT JOIN user_social_profiles usp ON u.id = usp.user_id
      WHERE (
        u.first_name ILIKE $1 OR 
        u.last_name ILIKE $1 OR 
        u.email ILIKE $1 OR
        usp.current_position ILIKE $1 OR
        usp.current_institution ILIKE $1 OR
        EXISTS (
          SELECT 1 FROM unnest(usp.research_interests) AS interest 
          WHERE interest ILIKE $1
        )
      )
      AND u.id != $2
      ORDER BY 
        CASE WHEN u.first_name ILIKE $3 OR u.last_name ILIKE $3 THEN 1 ELSE 2 END,
        usp.followers_count DESC NULLS LAST
      LIMIT $4 OFFSET $5
    `;
        const searchTerm = `%${q}%`;
        const exactSearchTerm = `${q}%`;
        const result = await pool.query(searchQuery, [
            searchTerm, req.user.id, exactSearchTerm, parseInt(limit), parseInt(offset)
        ]);
        res.json({ users: result.rows });
    }
    catch (error) {
        console.error('Error searching users:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
export default router;
//# sourceMappingURL=socialNetworking.js.map