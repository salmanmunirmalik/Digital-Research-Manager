/**
 * Negative Results Database API Routes
 * Revolutionary feature: Document and share failed experiments
 * Give researchers credit for transparency and save community time/money
 */
import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=negativeResults.d.ts.map