/**
 * AI Training API Routes
 * Personalized AI training for each scientist using RAG
 */
import { type Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=aiTraining.d.ts.map