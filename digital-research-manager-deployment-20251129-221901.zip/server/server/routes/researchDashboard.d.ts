declare const _default: {};
export default _default;
//# sourceMappingURL=researchDashboard.d.ts.map