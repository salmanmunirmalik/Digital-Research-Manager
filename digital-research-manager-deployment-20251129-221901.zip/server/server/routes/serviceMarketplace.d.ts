/**
 * Service Provider Marketplace API Routes
 * Handles service listings, requests, projects, work packages, and reviews
 */
import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=serviceMarketplace.d.ts.map