/**
 * External Databases API Routes
 * Exposes Materials Project and Lens.org integration
 * Based on user suggestions for materials data and current research insights
 */
import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=externalDatabases.d.ts.map