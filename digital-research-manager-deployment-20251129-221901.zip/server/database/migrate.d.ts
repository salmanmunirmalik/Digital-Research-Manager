interface Migration {
    id: string;
    name: string;
    sql: string;
    executed_at?: Date;
}
declare class DatabaseMigrator {
    private migrationsTable;
    init(): Promise<void>;
    getExecutedMigrations(): Promise<string[]>;
    executeMigration(migration: Migration): Promise<void>;
    runMigrations(migrationsDir?: string): Promise<void>;
    private getMigrationFiles;
    close(): Promise<void>;
}
export default DatabaseMigrator;
//# sourceMappingURL=migrate.d.ts.map