import { Pool } from 'pg';
declare const pool: Pool;
export default pool;
//# sourceMappingURL=config.d.ts.map