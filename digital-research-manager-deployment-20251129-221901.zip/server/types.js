// Digital Research Manager - TypeScript Types
// Based on PostgreSQL database schema
export {};
//# sourceMappingURL=types.js.map