# Deployment Instructions

## Prerequisites
- Node.js 18+ installed
- PostgreSQL database running
- pnpm installed (`npm install -g pnpm`)

## Steps

1. **Extract the zip file**
   ```bash
   unzip digital-research-manager-deployment-*.zip
   cd deployment
   ```

2. **Install dependencies**
   ```bash
   pnpm install --production
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your database credentials and other settings
   ```

4. **Run database migrations**
   ```bash
   # Make sure PostgreSQL is running and database exists
   ./scripts/run-migration-with-password.sh
   ```

5. **Start the application**
   ```bash
   # For production
   NODE_ENV=production pnpm start:prod
   
   # Or use PM2
   pm2 start dist/server/server/index.js --name research-manager
   ```

6. **Set up reverse proxy (nginx/apache)**
   - Point to the frontend build in `dist/`
   - Proxy API requests to `http://localhost:5002`

## DirectAdmin Deployment

See `DEPLOYMENT_DIRECTADMIN.md` for detailed DirectAdmin-specific instructions.

## Health Check

After deployment, verify:
- Frontend: `http://your-domain.com`
- Backend API: `http://your-domain.com/api/health`
- Database: Check connection in `.env`

## Troubleshooting

- Check logs: `pm2 logs research-manager`
- Verify database connection
- Check port 5002 is not in use
- Verify all environment variables are set
